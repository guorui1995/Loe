//
//  CARViewController.m
//  App
//
//  Created by lx on 16/8/27.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "CARViewController.h"

#define CellIdentifier @"tableViewCellIdentifier"

@interface CARViewController ()<UITableViewDelegate, UITableViewDataSource> {
    
    bool _isTapped[20];   }

@property (nonatomic, strong) NSArray * dataArray;


@property (nonatomic, strong) NSMutableArray * groupNames;

@property (nonatomic, strong) NSMutableArray * friendsArray;
//图片
@property (nonatomic, strong)NSMutableArray * friends0Array;

// 表视图
@property (nonatomic, strong) UITableView * tableView;

@end

@implementation CARViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self _loadData];
    
    self.tableView= [[UITableView alloc] initWithFrame:CGRectMake(0,54,375 ,667) style:UITableViewStyleGrouped];
    self.view.backgroundColor  = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1] ;
      self.tabBarController.tabBar.hidden = YES ;
//    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    
    
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];
    
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:CellIdentifier];
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 20, 80, 40)];
    [btn setTitle:@"< 汽车" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];

    
    
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.groupNames.count;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (_isTapped[section]) {
        return 0;
    }
    
    NSArray * friends = self.friendsArray[section];
    return friends.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    
    NSArray * friends = self.friendsArray[indexPath.section];
    NSArray *friends0 = self.friends0Array[indexPath.section];
    NSString * name = friends[indexPath.row];
    NSString *jpg=friends0[indexPath.row];
    NSLog(@"%@",jpg);
    cell.textLabel.text = name;
    cell.imageView.image=[UIImage imageNamed:jpg];
    return cell;
}
-(void)btnAction:(UIButton *)sebder{
    
    [self dismissViewControllerAnimated:YES completion:nil];

}


#pragma mark - Table view delegate
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [btn setTitle:self.groupNames[section] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"tableCell_common"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    btn.tag = section + 100;
    btn.layer.cornerRadius = 20;
    
    btn.clipsToBounds = YES;
    
    return btn;
}



- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 50;
}





#pragma mark - Private Methon
- (void)_loadData {
    
    self.groupNames = [NSMutableArray array];
    self.friendsArray = [NSMutableArray array];
    self.friends0Array=[NSMutableArray array];
    
    NSString * path = [[NSBundle mainBundle] pathForResource:@"friends" ofType:@"plist"];
    
    NSArray * dataArr = [NSArray arrayWithContentsOfFile:path];
    
    for (NSDictionary * dict in dataArr) {
        
        NSString * groupName = dict[@"group"];
        [self.groupNames addObject:groupName];
        
        NSArray * friends = dict[@"friends"];
        [self.friendsArray addObject:friends];
        NSArray *friends0=dict[@"friends0"];
        [self.friends0Array addObject:friends0];
    }
}



- (void)buttonAction:(UIButton *)sender {
    NSLog(@"click");
    
    NSInteger section = sender.tag - 100;
    _isTapped[section] = !_isTapped[section];
    NSIndexSet * set = [NSIndexSet indexSetWithIndex:section];
    [self.tableView reloadSections:set withRowAnimation:UITableViewRowAnimationFade];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

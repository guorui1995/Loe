//
//  ZAzhaohuController.m
//  App
//
//  Created by apple on 16/8/28.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "ZAzhaohuController.h"

@interface ZAzhaohuController ()<UITableViewDataSource,UITableViewDelegate>

@end

@implementation ZAzhaohuController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.85 green:0.85  blue:0.85 alpha:1];
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 75, 375, 100)];
    view.backgroundColor = [UIColor whiteColor];
    UIImageView * image = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, view.bounds.size.height-20, view.bounds.size.height - 20)];
    image.image = [UIImage imageNamed:@"nini"];
    [view addSubview:image];
    
    [self.view addSubview:view];
    
  
    UIView * view1 = [[UIView alloc]initWithFrame:CGRectMake(0, 190, [UIScreen mainScreen].bounds.size.width, 44)];
    view1.backgroundColor = [UIColor whiteColor];
    UILabel * lab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 44)];
    lab.text = @"设置备注和标签";
    
    [self.view addSubview:view1];
    [view1 addSubview:lab];
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(10,415 , [UIScreen mainScreen].bounds.size.width-20, 45)];
    btn.backgroundColor = [UIColor greenColor];
    [btn setTitle:@"打招呼" forState:UIControlStateNormal];
    [self.view addSubview:btn];
    
    
    UIButton * btn1 = [[UIButton alloc]initWithFrame:CGRectMake(10,465 , [UIScreen mainScreen].bounds.size.width-20, 44)];
    btn1.backgroundColor = [UIColor whiteColor];
    [btn1 setTitle:@"投诉" forState:UIControlStateNormal];
    
    [btn1 setTitleColor:[UIColor  blackColor] forState:UIControlStateNormal];
    [self.view addSubview:btn1];

    
    
    
    UITableView * tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 250, 375, 150) style:UITableViewStylePlain];
    // 设置数据源
    tableView.dataSource = self;
    tableView.delegate = self;
    
    [self.view addSubview:tableView];
    
    
    
    
    [self _tuichu];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{


    return  3;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
 UITableViewCell * cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];

    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 375, 40)];
    
    [cell addSubview:label];
    
    if (indexPath.row ==0) {
        label.text = @"地区：  四川  广元";
        
    }else if(indexPath.row ==1 ){
     label.text = @"个人相册";
    }

    else {
    label.text = @"更多";
    
    }

    return cell;
}




-(void)_tuichu{
    
    
    
    UIImageView *image = [[UIImageView
                           alloc]initWithFrame:CGRectMake(0, 20, 375, 44)];
    
    image.backgroundColor =[UIColor colorWithRed:0.3 green:0.3 blue:0.3 alpha:1];
    
    [self.view addSubview: image];
    
    
    
    UIButton *fanhui = [[UIButton alloc]initWithFrame:CGRectMake(20, 0, 30, 44)];
    [fanhui setTitle:@"返回" forState:UIControlStateNormal];
    [fanhui setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
  
    [fanhui addTarget:self action:@selector(fanhuiAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:fanhui];
    
 
    
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(70, 5, 100, 40)];
    label.text = @"详细资料";
    label.textColor = [UIColor whiteColor];
    
    [image addSubview:label];
    
    

}

-(void)fanhuiAction:(UIButton *)sender{

   [self dismissViewControllerAnimated:YES completion:nil];

}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

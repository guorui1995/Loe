//
//  GRFoundViewController.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "GRFoundViewController.h"
#import "ZAAddressViewController.h"
#import "YXViewController.h"
#import "CARViewController.h"
#import "ZZCrowdFundingViewController.h"
#import "moviewController.h"
#import "ZArangeController.h"
#import "AXViewController.h"
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

@interface GRFoundViewController ()<UICollectionViewDataSource>

@property(nonatomic,strong) UIScrollView * scrollView;
@end

@implementation GRFoundViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    self.title = @"发现";
    self.tabBarController.tabBar.hidden = NO ;
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"B803A185-1C51-472D-85C9-9A61BB5E66AA"]];
    
    
    self.scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 64, kScreenWidth, 120)];
    [self.view addSubview:self.scrollView];
    //
    self.scrollView.contentSize = CGSizeMake(kScreenWidth*8, 0) ;
    self.scrollView.pagingEnabled = YES;
    
    for (int i = 0; i < 8; i++) {
        UIImageView  * imageview = [[UIImageView alloc]initWithFrame:CGRectMake(i*kScreenWidth, 0, kScreenWidth, 120)];
        
        imageview.image = [UIImage imageNamed:[NSString stringWithFormat:@"00%d",i+1]];
        
        [self.scrollView addSubview:imageview];
        
        
    }
    
    
    
    //创建下面的应用
    UICollectionViewFlowLayout * flowLayout = [[UICollectionViewFlowLayout alloc]init];
    flowLayout.itemSize = CGSizeMake(70, 70);
    
    //单元格间距为 10
    flowLayout.minimumInteritemSpacing = 10;
    flowLayout.minimumLineSpacing = 40;
    
    UICollectionView * collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 64+120, kScreenWidth, kScreenHeight - 64 - 120) collectionViewLayout:flowLayout];
    
    collectionView.backgroundColor = [UIColor clearColor];
    
    //签订数据源协议
    collectionView.dataSource = self;
    
    collectionView.contentInset = UIEdgeInsetsMake(20, 20, 20, 20) ;
    
    [collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellID"];
    
    
    
    [self.view addSubview:collectionView];
    
    
    }

#pragma mark --- collection view data source

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return 8;
    
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    //使用服用方法，获取单元
    
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellID" forIndexPath:indexPath];
    UIButton *button = [[UIButton alloc]initWithFrame:cell.bounds];
    button.tag = indexPath.item + 100;
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [cell addSubview:button];
    
    cell.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:[NSString stringWithFormat:@"00%ld0",indexPath.item+1]]];
    
    cell.layer.cornerRadius = 14;
    cell.clipsToBounds = YES;
    //
    //
    //
    NSArray *array = @[@"找人",@"周围",@"游戏",@"电影",@"众筹",@"通讯录",@"汽车",@"爱心捐赠",];
    //
    for (int i = 0; i < 8; i++) {
     
        if (i<4) {
            //
            UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(i*89, 70, 70, 30)];
            
            label.text = array[i];
            label.textAlignment =  NSTextAlignmentCenter;
            label.font = [UIFont systemFontOfSize:15];
            [collectionView addSubview: label];
            
            
        }else{
            UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(i%4*89, 70+40+70, 70, 30)];
            label.font = [UIFont systemFontOfSize:15];
            label.text = array[i];
            label.textAlignment =  NSTextAlignmentCenter;
            [collectionView addSubview: label];
            
            
        }
    }
    return  cell;
    
}


-(void)buttonAction:(UIButton *)sender{
    
    switch (sender.tag-100) {
        case 5:
            [self presentViewController:[[ZAAddressViewController alloc]init] animated:YES completion:nil];            break;
        case 2:
            [self presentViewController:[[YXViewController alloc]init] animated:YES completion:nil];
              break;
         case 6:
            [self presentViewController:[[CARViewController alloc]init] animated:YES completion:nil];
              break;
        case 4:
            [self presentViewController:[[ZZCrowdFundingViewController alloc]init] animated:YES completion:nil];            break;
            
        case 3:
            [self.navigationController pushViewController:[[moviewController alloc]init] animated:YES];
            break;
            
        case  1:
            [self.navigationController pushViewController:[[ZArangeController alloc]init] animated:YES  ];
            break;
            
        case  7:
            [self.navigationController pushViewController:[[AXViewController alloc]init] animated:YES  ];
            break;
            
    }
    
}

 - (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  ZAAddressViewController.m
//  App
//
//  Created by lx on 16/8/25.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "ZAAddressViewController.h"

@interface ZAAddressViewController ()<UITableViewDataSource>
//数组
@property (nonatomic, strong) NSArray * provincesArray;

//字典
@property (nonatomic, strong) NSDictionary * citiesDic;
@end

@implementation ZAAddressViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self _containData];
     self.tabBarController.tabBar.hidden = YES ;
    
    UITableView * tableView = [[UITableView alloc] initWithFrame:CGRectMake(0,104,375 ,667) style:UITableViewStyleGrouped];
    // 设置数据源
    tableView.dataSource = self;
    
    
    [self.view addSubview:tableView];
    
    
    tableView.sectionIndexColor = [UIColor blueColor];
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 20, 80, 40)];
    [btn setTitle:@"通讯录" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];

    
    
    
   }

- (void)_containData {
    // 获取文件信息
    NSString * pPath = [[NSBundle mainBundle] pathForResource:@"provinces" ofType:@"plist"];
    NSString * cPath = [[NSBundle mainBundle] pathForResource:@"cities" ofType:@"plist"];
//    搜索
    UISearchBar  *bar = [[UISearchBar alloc]initWithFrame:CGRectMake(0,64, 375, 40)];
    bar.layer.cornerRadius = 14;
    bar.clipsToBounds = YES;
    [self.view addSubview:bar];
    
    
    self.provincesArray = [NSArray arrayWithContentsOfFile:pPath];
    self.citiesDic = [NSDictionary dictionaryWithContentsOfFile:cPath];
}

#pragma mark - Table View DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return self.provincesArray.count;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSString * provinceName = self.provincesArray[section];
    
    
    NSArray * citiesArr = self.citiesDic[provinceName];
    
    return citiesArr.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell * cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    
    NSString * provinceName = self.provincesArray[indexPath.section];
    
    
    NSArray * citiesArr = self.citiesDic[provinceName];
    
    
    NSString * cityName = citiesArr[indexPath.row];
    
    
    cell.textLabel.text = cityName;
    
    
    return cell;
}



- (nullable NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    
    return self.provincesArray;
}



- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return self.provincesArray[section];
}
-(void)btnAction:(UIButton *)sender{
    [self dismissViewControllerAnimated:YES completion:nil];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

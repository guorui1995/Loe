//
//  AXViewController.m
//  App
//
//  Created by lx on 16/8/28.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "AXViewController.h"

@interface AXViewController ()<UITableViewDataSource, UITableViewDelegate>
@property(nonatomic,strong)NSMutableArray *mutaarray;
@property(nonatomic,strong)NSMutableArray *jianjiearray;
@property(nonatomic,assign)NSInteger rmb;

@end

@implementation AXViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [super viewDidLoad];
    
    self.title=@"💗捐款💗";
    
    UITableView * tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 375, 705)style:UITableViewStyleGrouped];
    
    tableView.rowHeight = 200;
    // 想要对单元格进行操作，需要设置数据源协议
    tableView.dataSource = self;
    // 单元格事件都和代理相关
    tableView.delegate = self;
    [self.view addSubview:tableView];
    
    UISearchBar  *bar = [[UISearchBar alloc]initWithFrame:CGRectMake(0,64, 375, 40)];
    bar.layer.cornerRadius = 14;
    bar.clipsToBounds = YES;
    [self.view addSubview:bar];
    [self _containData];
}
- (void)_containData{
    
    NSString *strmove = [[NSBundle mainBundle]pathForResource:@"juanKuan.plist" ofType:nil];
    NSArray *arraymove =[NSArray arrayWithContentsOfFile:strmove];
    
    self.mutaarray = [NSMutableArray array];
    self.jianjiearray=[NSMutableArray array];
    
    NSDictionary *dis=arraymove[0];
    self.mutaarray=dis[@"item"];
    //self.jianjiearray=dis[@"item2"];
    
    
}

//-(void)buttonAction:(UIButton *)sender{
//
//
//}

#pragma mark - 表视图数据源协议

// 指定组数，在group情况下，你有几组TableView，默认情况下，组数为1
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}



// 指定每一组单元格的行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 5;
}

// 实现每一行的单元格
// 返回单元格，返回NSIndexPath所指向位置的单元格
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    // 简单的实现，暂时不考虑复用问题
    UITableViewCell * cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    
    cell.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
    
    
    
    
    UIImageView  *image = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 375, 200)];
    
    image.image =[UIImage imageNamed:self.mutaarray[indexPath.row]];
    [cell addSubview:image];
    if (indexPath.row ==0 ) {
        
    }else{
        
        UIButton  *button = [[UIButton alloc]initWithFrame:CGRectMake(0, 5, 50, 30)];
        //按钮颜色
        
        [button  setBackgroundColor:[UIColor colorWithRed:1 green:0.5 blue:0.1 alpha:1]];
        
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
        button.layer.cornerRadius = 14;
        button.titleLabel.font = [UIFont systemFontOfSize:14];
        button.clipsToBounds = YES;
        [button addTarget:self action:@selector(goupiaoAction:) forControlEvents:UIControlEventTouchUpInside];
        
        [button setTitle:@"捐款" forState:UIControlStateNormal];
        UIButton  *button1 = [[UIButton alloc]initWithFrame:CGRectMake(375-50, 5, 50, 30)];
        //按钮颜色
        
        [button1  setBackgroundColor:[UIColor colorWithRed:1 green:0.5 blue:0.1 alpha:1]];
        
        [button1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        button1.layer.cornerRadius = 14;
        button1.titleLabel.font = [UIFont systemFontOfSize:14];
        button1.clipsToBounds = YES;
        [button1 addTarget:self action:@selector(goupiaoAction:) forControlEvents:UIControlEventTouchUpInside];
        
        [button1 setTitle:@"捐款" forState:UIControlStateNormal];
        
        [cell addSubview: button];
        [cell addSubview: button1];
        
    }

    return cell;
    
}

-(void)goupiaoAction:(UIButton *)sender{

    UIAlertController * alertView = [UIAlertController alertControllerWithTitle:@"亲！ 确定要爱心捐款？ " message:nil  preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    UIAlertAction * alertAction2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    [alertView addAction:alertAction1];
    [alertView addAction:alertAction2];
    [self presentViewController:alertView animated:YES completion:nil];
    
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

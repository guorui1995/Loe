//
//  moviewController.m
//  App
//
//  Created by apple on 16/8/27.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "moviewController.h"
    
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.heigh
    @interface moviewController ()<UITableViewDataSource, UITableViewDelegate,UIScrollViewDelegate>
    @property (nonatomic, strong) UIPageControl * pageCtrl;
    @property (nonatomic, strong) UIScrollView * scrollView;
    @property(nonatomic,strong)UIButton*button;
    @property(nonatomic,strong)NSMutableArray *mutaarray;
    @property(nonatomic,strong)NSMutableArray *jianjiearray;
    @property(nonatomic,strong)UIImageView *imageView;
    @property(nonatomic,assign)NSInteger rmb;
    @end
    @implementation moviewController
    
    - (void)viewDidLoad {
        [super viewDidLoad];
        
        self.title=@"电影";
        
        UITableView * tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 154, 375, 600)style:UITableViewStyleGrouped];
        
        tableView.rowHeight = 100;
        // 想要对单元格进行操作，需要设置数据源协议
        tableView.dataSource = self;
        // 单元格事件都和代理相关
        tableView.delegate = self;
        [self.view addSubview:tableView];
        
        
        
        UISearchBar  *bar = [[UISearchBar alloc]initWithFrame:CGRectMake(0,64, 375, 40)];
        bar.layer.cornerRadius = 14;
        bar.clipsToBounds = YES;
        [self.view addSubview:bar];
        
        
        
        self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 105, 375, 150)];
        [self.view addSubview:self.scrollView];
        //
        // 设置内容尺寸
        self.scrollView.contentSize = CGSizeMake(kScreenWidth * 5, 0);
        self.scrollView.pagingEnabled = YES;
        
        self.scrollView.showsHorizontalScrollIndicator = NO;
        //
        //    // 创建子视图
        for (int i = 0; i < 5; i++) {
            
            UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(i * kScreenWidth, 0, kScreenWidth, 200)];
            imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"3%d", i]];
            [self.scrollView addSubview:imageView];
            if(i==1){
                
                UIButton * presentBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 50, 100, 150)];
                [presentBtn addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
                [self.view addSubview:presentBtn];
            }
            
            
            
            self.scrollView.delegate = self;
            
            //    // 页码控件
            self.pageCtrl = [[UIPageControl alloc] initWithFrame:CGRectMake(0,  240, kScreenWidth, 20)];
            // 页码数
            self.pageCtrl.numberOfPages = 5;
            // 当前选中页面
            self.pageCtrl.currentPage = 0;
            
            // 未选中点颜色
            self.pageCtrl.pageIndicatorTintColor = [UIColor blueColor];
            // 当前点的颜色
            self.pageCtrl.currentPageIndicatorTintColor = [UIColor redColor];
            
            self.pageCtrl.enabled = NO;
            
            //    // 添加事件
            [self.pageCtrl addTarget:self action:@selector(movePageCtrl:) forControlEvents:UIControlEventValueChanged];
            
            [self.view addSubview:self.pageCtrl];
        }
        [self _containData];
    }
    - (void)_containData{
        
        NSString *strmove = [[NSBundle mainBundle]pathForResource:@"Property List.plist" ofType:nil];
        NSArray *arraymove =[NSArray arrayWithContentsOfFile:strmove];
        
        self.mutaarray = [NSMutableArray array];
        self.jianjiearray=[NSMutableArray array];
        
        NSDictionary *dis=arraymove[0];
        self.mutaarray=dis[@"item"];
        self.jianjiearray=dis[@"item2"];
        
        
    }
    
    -(void)buttonAction:(UIButton *)sender{
        
        
    }
    
#pragma mark - 表视图数据源协议
    
    // 指定组数，在group情况下，你有几组TableView，默认情况下，组数为1
    - (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
        return 1;
    }
    
    
    
    // 指定每一组单元格的行数
    - (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
        
        return 8;
    }
    
    // 实现每一行的单元格
    // 返回单元格，返回NSIndexPath所指向位置的单元格
    - (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
        
        
        // 简单的实现，暂时不考虑复用问题
        UITableViewCell * cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        
        cell.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
        
        
        
        
        
        UIImageView  *image = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 70, 70)];
        
        image.image =[UIImage imageNamed:self.mutaarray[indexPath.row]];
        
        UIButton  *button = [[UIButton alloc]initWithFrame:CGRectMake(300, 5, 50, 30)];
        
        [button  setBackgroundColor:[UIColor colorWithRed:1 green:0.5 blue:0.1 alpha:1]];
        
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        button.layer.cornerRadius = 14;
        button.titleLabel.font = [UIFont systemFontOfSize:14];
        button.clipsToBounds = YES;
        [button addTarget:self action:@selector(goupiaoAction:) forControlEvents:UIControlEventTouchUpInside];
        
        [button setTitle:@"购票" forState:UIControlStateNormal];
        
        [cell addSubview: button];
        
        
        
        UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(100, 5, 200, 40)];
        label.textAlignment =  NSTextAlignmentCenter ;
        label.text=self.mutaarray[indexPath.row];
        
        label.font = [UIFont boldSystemFontOfSize:20.f];
        label.textColor=[UIColor blackColor];
        
        [cell addSubview:label];
        
        [cell addSubview:image];
        
        
        UILabel *label2=[[UILabel alloc]initWithFrame:CGRectMake(100, 30, 270, 65)];
        label2.font = [UIFont systemFontOfSize:14.f];
        label2.text=self.jianjiearray[indexPath.row];
        label2.numberOfLines = 0;
        
        label2.textColor = [UIColor blackColor];
        [cell addSubview:label2];
        
        
        return cell;
        
    }
    
    -(void)goupiaoAction:(UIButton *)sender{
        
        self.rmb = arc4random_uniform(100);
        NSString * str  = [NSString stringWithFormat:@"本次购票:%ld元",self.rmb ];
        UIAlertController * alertView = [UIAlertController alertControllerWithTitle:@"亲！ 欢迎购票 " message:str  preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction * alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        
        UIAlertAction * alertAction2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        
        [alertView addAction:alertAction1];
        [alertView addAction:alertAction2];
        [self presentViewController:alertView animated:YES completion:nil];
        
        
    }
    
    
    
    
    
    ////这是导航栏图片方法
    - (void)movePageCtrl:(UIPageControl *)pageControl {
        
        //    // X轴偏移量
        CGFloat contentOffsetX = pageControl.currentPage * kScreenWidth;
        
        //    // 直接修改滑动视图的偏移量（没有动画效果！）
        self.scrollView.contentOffset = CGPointMake(contentOffsetX, 0);
        //
        //    // 改变偏移量有动画效果
        [self.scrollView setContentOffset:CGPointMake(contentOffsetX, 0) animated:YES];
        
    }
    - (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset NS_AVAILABLE_IOS(5_0) {
        
        // 目标偏移量
        CGPoint point = *targetContentOffset;
        
        // 当前页面数 = 当前偏移量 / 屏幕宽度
        NSInteger pageNum = point.x / kScreenWidth;
        
        // 将页码控件的当前页面值设为计算后的值
        self.pageCtrl.currentPage = pageNum;
    }
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

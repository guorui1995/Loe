//
//  ZArangeController.m
//  App
//
//  Created by apple on 16/8/27.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "ZArangeController.h"
#import "ZAzhaohuController.h"
@interface ZArangeController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)NSMutableArray *touxiang;
@property(nonatomic,strong)NSMutableArray *mingcheng;
@property(nonatomic,strong)NSMutableArray *juli;
@property(nonatomic,strong)NSMutableArray *qianming;
@end

@implementation ZArangeController

- (void)viewDidLoad {
    [super viewDidLoad];
    UITableView * tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, 375, [UIScreen mainScreen].bounds.size.height)];
    
    tableview.rowHeight = 70;
    // 想要对单元格进行操作，需要设置数据源协议
    tableview.dataSource = self;
    // 单元格事件都和代理相关
    tableview.delegate = self;
    
    [self.view addSubview:tableview];
    
    [self _containData];
    
}

- (void)_containData{
    
    self.touxiang = [NSMutableArray array];
    self.mingcheng = [NSMutableArray array];
    self.juli = [NSMutableArray array];
    self.qianming = [NSMutableArray array];
    

    NSString *strmove = [[NSBundle mainBundle]pathForResource:@"range.plist" ofType:nil];
    NSArray *arraymove =[NSArray arrayWithContentsOfFile:strmove];
    

  
    for (NSDictionary * dict in arraymove) {
        
        NSString * groupName = dict[@"ming"];
        
        [self.mingcheng addObject:groupName];
        
        NSString *touxiang = dict[@"touxiang"];
        
      
        [self.touxiang addObject:touxiang];
      
        NSString *ju = dict [@"juli"];
        [self.juli addObject:ju];
        
        NSString *qian = dict [@"qianming"];
        [self.qianming addObject:qian];
        
    }
 
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 9;

}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    // 简单的实现，暂时不考虑复用问题
    UITableViewCell * cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    
    cell.backgroundColor = [UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1];
    
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 40, 40)];
    
    image.layer.cornerRadius = 10;
    image.clipsToBounds = YES;
   NSString * photo = self.touxiang[indexPath.row];
    
    image.image = [UIImage imageNamed:photo];
    
    [cell addSubview:image];
    

    UILabel *label= [[UILabel alloc]initWithFrame:CGRectMake(70, 5, 80, 40)];
    
    NSString * ming = self.mingcheng [indexPath.row];
    
    label.text = ming;
    
    label.textColor = [UIColor blackColor];
    
    [cell addSubview:label];
    
    UILabel *label1= [[UILabel alloc]initWithFrame:CGRectMake(70, 50,60, 20)];
    
    NSString * ju = self.juli [indexPath.row];
    
    label1.text = ju;
    label1.font = [UIFont systemFontOfSize:10.f];
    label1.textColor = [UIColor blackColor];
    
    [cell addSubview:label1];
    
    UILabel *label2= [[UILabel alloc]initWithFrame:CGRectMake(250, 5,110, 50)];
    
    NSString * qian = self.qianming [indexPath.row];
    
    label2.text = qian;
    
    label2.font = [UIFont systemFontOfSize:12.f];
    label2.textColor = [UIColor blackColor];
    
    [cell addSubview:label2];
    
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 375, 70)];
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [cell addSubview:button];
    
    

    

    return cell;
}

-(void)buttonAction:(UIButton *)sender{

            [self presentViewController:[[ZAzhaohuController alloc]init] animated:YES completion:nil];
    
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

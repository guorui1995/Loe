//
//  YANSEViewController.m
//  App
//
//  Created by lx on 16/8/26.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "YANSEViewController.h"

@interface YANSEViewController ()
{
    UIButton * imageButton;
    UIButton * hideButton;
    UIButton * submitButton;
    UIButton * undoButton;
    NSInteger _s,_ss;
    NSInteger a;
    int p;
}
@property(nonatomic,strong)UILabel *timeLabel;
//计时器用来刷新时间
@property(nonatomic,strong)NSTimer *runTimer;

@end

@implementation YANSEViewController

- (void)viewDidLoad {
    [self creatTimer];
    p = 2;
    [super viewDidLoad];
    NSInteger width = (self.view.bounds.size.width)/4;
    NSInteger height = self.view.bounds.size.height;
    //显示时间
    self.timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(width*1.25-30, height-50, width+120, 50)];
    
    self.timeLabel.backgroundColor = [UIColor whiteColor];
    
    // Do any additional setup after loading the view.
    [self playGame];
    
     [self.view addSubview:self.timeLabel];
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 10, 100, 60)];
    [btn setTitle:@"色盲游戏" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
}
-(void)btnAction:(UIButton *)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)playGame{
    // 1. 先将原来的v移除
    UIView *view = [self.view viewWithTag:987];
    [view removeFromSuperview];
    a++;
    if (a %5 == 0) {
        p ++;
    }
    NSInteger height=(self.view.bounds.size.height)/p;
    NSInteger width=(self.view.bounds.size.width)/p;
    UIView *v = [[UIView alloc]initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, height*p-100)];
    v.tag = 987;
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    v.backgroundColor = [UIColor whiteColor];
    
    int s = arc4random()%(p*p);
    CGFloat hue = ( arc4random() % 128 / 256.0 )+0.5;
    CGFloat saturation = ( arc4random() % 128 / 256.0 ) + 0.5;
    CGFloat brightness = ( arc4random() % 128 / 256.0 ) + 0.5;
    for (int i = 0; i < p*p; i++) {
        imageButton = [[UIButton alloc]initWithFrame:CGRectMake(width*(i/p+0.025), ((height*0.83) *(i%p)), width*0.95, height*0.8)];
        if (i == s ) {
            imageButton.backgroundColor = [UIColor colorWithHue:hue saturation:saturation brightness:brightness alpha:(0.5+0.01*a)];
            [imageButton addTarget:self action:@selector(playGame) forControlEvents:UIControlEventTouchDown];
        }else{
            imageButton.backgroundColor = [ UIColor colorWithHue:hue saturation:saturation brightness:brightness alpha:1];
        }
        [v addSubview:imageButton];
    }
    [self.view addSubview:v];
}

- (void)creatTimer{
    [self.runTimer setFireDate:[NSDate distantPast]];
    self.runTimer=[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerAction) userInfo:nil repeats:YES];
  
}

- (void)timerAction{
    if (++_s>=30) {
        _s=0;
        NSString *str = [NSString stringWithFormat:@"您一共找出来了%ld张图片",a-1];
        UIAlertView *aler = [[UIAlertView alloc]initWithTitle:@"恭喜" message:str delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        p = 2;
        [aler show];
        [self.runTimer setFireDate:[NSDate distantFuture]];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    self.timeLabel.text=[NSString stringWithFormat:@"剩余时间%02zd",30-_s];
    self.timeLabel.textAlignment = NSTextAlignmentCenter;
}
- (void)clickOnButton:(UIButton *)imageButton{
    
  
}
- (void)viewDidDisappear:(BOOL)animated{
    [self.runTimer invalidate];
}
-(BOOL)prefersStatusBarHidden{
    return NO;
}

    // Dispose of any resources that can be recreated.

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

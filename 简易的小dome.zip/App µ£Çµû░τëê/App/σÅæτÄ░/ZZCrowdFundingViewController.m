//
//  ZZCrowdFundingViewController.m
//  App
//
//  Created by lx on 16/8/26.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "ZZCrowdFundingViewController.h"
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
@interface ZZCrowdFundingViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>
@property(strong,nonatomic)NSMutableArray * imagearry;

@end
#define cellID @"CollectionViewCellIdentifier"
@implementation ZZCrowdFundingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBarController.tabBar.hidden = YES ;
    self.automaticallyAdjustsScrollViewInsets=NO;
    //标题设置
    UIScrollView *scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 64,kScreenWidth ,40)];
    scrollView.backgroundColor=[UIColor redColor];
    
    scrollView.contentSize=CGSizeMake(kScreenWidth, 0);
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.pagingEnabled = YES;
    scrollView.backgroundColor = [UIColor colorWithRed:0.3 green:0.3 blue:0.3 alpha:1];
    NSArray * arry=@[@"精选",@"科技",@"设计",@"娱乐",@"其他"];
    for (int i = 0; i<5; i++) {
        UIButton *but=[[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth/5*i, -5,kScreenWidth/5 ,50 )];
         [but addTarget:self action:@selector(butAtion:) forControlEvents:UIControlEventTouchUpInside];
        [but setTitle:arry[i] forState:UIControlStateNormal];
        
        if( i == 1){
            [but setBackgroundColor:[UIColor colorWithRed:0.4 green:0.85 blue:0.85 alpha:1]];
        }
        [scrollView addSubview:but];
    }
    [self.view addSubview:scrollView];
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 20, 80, 40)];
    [btn setTitle:@"众筹" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];

    
    //选项设置
    UIScrollView *scrollView1=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 104,kScreenWidth ,50)];
    
    scrollView1.contentSize=CGSizeMake(kScreenWidth, 0);
    scrollView1.showsHorizontalScrollIndicator = NO;
    scrollView1.showsVerticalScrollIndicator = NO;
    scrollView1.backgroundColor=[UIColor whiteColor];

      NSArray * arry1=@[@"即将上线",@"最新上线"];
    for (int i = 0; i<2; i++) {
        
        if ( i == 0) {
            UIButton *but=[[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth/2*i+50, 7,kScreenWidth/2-40 ,35 )];
            
            [but setTitle:arry1[i] forState:UIControlStateNormal];
            [but setBackgroundColor:[UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1]];
            but.layer.cornerRadius = 10;
            but.clipsToBounds = YES;
            [scrollView1 addSubview:but];
        }
        else{
            UIButton *but=[[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth/2*i-20, 7,kScreenWidth/2-40 ,35 )];
            
            [but setTitle:arry1[i] forState:UIControlStateNormal];
            [but setTitleColor:[UIColor cyanColor] forState:UIControlStateNormal];
            [but setBackgroundColor:[UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1]];
            but.layer.cornerRadius = 10;
            but.clipsToBounds = YES;
            [scrollView1 addSubview:but];
        }
    }
    [self.view addSubview:scrollView1];
//集合视图
    UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc]init];
    layout.itemSize=CGSizeMake(kScreenWidth/2-10,kScreenWidth/2-10);
       layout.minimumInteritemSpacing = 10;
    
    UICollectionView *collectionView=[[UICollectionView alloc]initWithFrame:CGRectMake(0, 154, kScreenWidth, kScreenHeight-160) collectionViewLayout:layout];
    collectionView.backgroundColor = [UIColor colorWithRed:0.85 green:0.85 blue:0.85 alpha:1];
    collectionView.dataSource=self;
    collectionView.delegate=self;
    [collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:cellID];
// 图片数组
    self.imagearry=[NSMutableArray array];
    for (int i = 0; i<10; i++) {
        NSString *str=[NSString stringWithFormat:@"z%d",i];
        [self.imagearry addObject:str];
    }
    
    [self.view addSubview:collectionView];
}
-(void)butAtion1:(UIButton *)sender{
    
}
-(void)butAtion:(UIButton *)sender{
    
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return self.imagearry.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    for (UILabel * lab in cell.subviews) {
        [lab removeFromSuperview];
    }
    UIImageView * imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0,kScreenWidth/2-10 ,kScreenWidth/2-10-60)];
    imageView.image=[UIImage imageNamed:self.imagearry[indexPath.item]];
    
    [cell addSubview:imageView];
    cell.backgroundColor=[UIColor whiteColor];
//   需要 3个数组 来改变；
    
    NSArray *arr = @[@"智能驾驶安全预警系统",@"真彩高清手机智能投影仪",@"乐聚智能人形机器人Aelos",@"无良L1炭纤维一体化电动滑板车，科技与艺术完美结合",@"合家科技智能家居控制终端门童 全家人都能用的智能机",@"一站式充电 - 手机“智网”WiFi充电站",@"云马智行车mini2代 - 星际迷航纪念版",@"改变出行，装在包包里的汽车",@"新一代科沃斯高端扫地机器人路径规划弓形清扫地",@"欧耶智能随身看片路由器，无需流量 多人共享",];
        UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(0, 110,kScreenWidth/2-10 ,50 )];
//    
    label.font = [UIFont systemFontOfSize:16.f ];
//    [label sizeToFit];
    label.numberOfLines = 0;
        label.text=arr[indexPath.item];
    
    
    
        UILabel *label1=[[UILabel alloc]initWithFrame:CGRectMake(0,160 ,kScreenWidth/2-10 , 20)];
    NSString *str1 = [NSString stringWithFormat:@"%d",arc4random_uniform(500)];
     label1.font = [UIFont systemFontOfSize:13.f ];
    label1.text = [NSString stringWithFormat:@"$%@",str1];
    
        
        UILabel *label2=[[UILabel alloc]initWithFrame:CGRectMake(80,160 ,kScreenWidth/2-10-80 , 20)];
    NSString *str = [NSString stringWithFormat:@"%d",arc4random_uniform(1000)];
     label2.font = [UIFont systemFontOfSize:13.f ];
        label2.text = [NSString stringWithFormat:@"人数%@",str];
        [cell addSubview:label];
        [cell addSubview:label1];
        [cell addSubview:label2];
    
    return cell;
}
-(void)btnAction:(UIButton *)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  YXViewController.m
//  App
//
//  Created by lx on 16/8/26.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "YXViewController.h"
#import "YANSEViewController.h"
#import "GRFoundViewController.h"
@interface YXViewController ()
{
    UIButton *button;
}
@end

@implementation YXViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.tabBarController.tabBar.hidden = YES ;
    
    
    button = [[UIButton alloc]initWithFrame:CGRectMake(100, 160, 200,80 )];
    [button setTitle:@"色盲游戏" forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:42];
    [button setTitleColor:[UIColor magentaColor] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(forget) forControlEvents:UIControlEventTouchUpInside];
    self.view.backgroundColor=[UIColor redColor];
    [self.view addSubview:button];
    
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(10, 40, 100, 60)];
    [btn setTitle:@"游戏" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}
-(void)btnAction:(UIButton *)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)forget{
    
    YANSEViewController * yanse=[[YANSEViewController alloc]init];
    [self presentViewController:yanse animated:YES completion:nil];
    
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  GRViewController.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//
#import "GRViewController.h"
#import "GRFoundViewController.h"
#import "GRHomePageViewController.h"
#import "ZAMyViewController.h"
@interface GRViewController ()

@end

@implementation GRViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 配置子控制器
    [self _configureViewControllers];
    // 自定义标签栏
    [self _customTabBar];
    
}
-(void)_configureViewControllers {
    //发现
    GRFoundViewController * found = [[GRFoundViewController alloc]init];
    //首页
    GRHomePageViewController * home = [[GRHomePageViewController alloc]init];
    //我的
    ZAMyViewController * my = [[ZAMyViewController alloc]init];
    home.zamyv=my;
    NSArray * vcArr = @[home,found,my];
    NSMutableArray * nagtArr = [NSMutableArray array];
    for (UIViewController * vc in vcArr) {
        UINavigationController * nagt = [[UINavigationController alloc]initWithRootViewController:vc];
        nagt.navigationBar.alpha = 1 ;
        [nagtArr addObject:nagt];
    }
    // 给标签栏控制器的viewController赋值
    self.viewControllers = nagtArr ;
    
}



-(void)_customTabBar {
    for (UIView * view  in self.tabBar.subviews) {
        [view removeFromSuperview];
    }
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    // 按钮宽度
    CGFloat itemWidth = screenWidth / self.viewControllers.count;
    NSArray * btnName = @[@"首页",@"发现",@"我的"];
    for (int i = 0; i<self.viewControllers.count; i++) {
        UIButton * button = [[UIButton alloc]initWithFrame:CGRectMake(itemWidth*i, 0, itemWidth, 49)];
        //设置按钮图片内容
        NSString * str = btnName[i];
        [button setTitle:str forState:UIControlStateNormal];
        
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.tabBar addSubview:button];
        [button addTarget:self action:@selector(changSubviecontrollerWithIndex:) forControlEvents:UIControlEventTouchUpInside];
        button.tag = i + 100 ;
    }
    
}
-(void)changSubviecontrollerWithIndex:(UIButton *)sender{
    
    //设置标签控制器选中那个子控制器
    self.selectedIndex = sender.tag -100;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

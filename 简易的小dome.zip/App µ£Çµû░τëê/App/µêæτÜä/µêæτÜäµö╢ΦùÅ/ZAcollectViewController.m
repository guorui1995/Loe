//
//  ZAcollectViewController.m
//  App
//
//  Created by lx on 16/8/25.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "ZAcollectViewController.h"
#import "ZAMymuisicViewController.h"
@interface ZAcollectViewController ()

@end

@implementation ZAcollectViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.view.backgroundColor = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1];

    [self _muisicbutton];

  }
-(void)_muisicbutton{
    
    //添加一个音乐播放按钮
    
    UIButton * button = [[UIButton alloc]initWithFrame:CGRectMake(0, 44+20+30, [UIScreen mainScreen].bounds.size.width, 30)];
    [button setTitle:@"音乐" forState: UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [ button setBackgroundColor:[UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1]];
    [button setTitleColor:[UIColor redColor] forState:UIControlStateHighlighted];
    button.layer.cornerRadius = 18;
    button.clipsToBounds = YES;
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
}

-(void)buttonAction:(UIButton *)sender{
    
//    [self.navigationController pushViewController:[[ZAMymuisicViewController alloc]init] animated:YES];
    [self presentViewController:[[ZAMymuisicViewController alloc]init]  animated:YES completion:nil];;
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  ZAMymuisicViewController.m
//  App
//
//  Created by lx on 16/8/25.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "ZAMymuisicViewController.h"
#import "ZAcollectViewController.h"
#import <AVFoundation/AVFoundation.h>
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

@interface ZAMymuisicViewController ()<UIScrollViewDelegate>

{
    //声明全局的播放器变量
    AVAudioPlayer * player;
}
//@property(strong,nonatomic)UIImageView * imageView;
@end

@implementation ZAMymuisicViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 创建一个滑动视图
    UIScrollView * scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.view addSubview:scrollView];
    // 开启分页效果
    scrollView.pagingEnabled = YES;
    // 取消显示水平滚动条
    scrollView.showsHorizontalScrollIndicator = NO;
    // 内容视图的大小
    scrollView.contentSize = CGSizeMake(23 * kScreenWidth, 0);
//     UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth, 0, kScreenWidth, kScreenHeight)];
//        imageView.image = [UIImage imageNamed:@"219"];
//    [scrollView addSubview:imageView];
//    UIImageView * imageView=[[UIImageView alloc]init];
    
    for (int i = 200; i < 222; i++) {
       UIImageView * imageView =[[UIImageView alloc]initWithFrame: CGRectMake((i-200) * kScreenWidth, 0, kScreenWidth, kScreenHeight)];
        // 根据不同的位置，添加不同的图片
        if (i == 200) {
            imageView.image = [UIImage imageNamed:@"219"];
        } else if (i == 221) {
            imageView.image = [UIImage imageNamed:@"200"];
        }else {
            NSString * imgName = [NSString stringWithFormat:@"%d", i];
            
            UIImage * image = [UIImage imageNamed:imgName];
            imageView.image = image;
        }
        // 添加图片到滑动视图上
        [scrollView addSubview:imageView];
    }
    
    scrollView.delegate = self;
    // 在界面显示之前，就要让scrollView偏移一定大小
    scrollView.contentOffset = CGPointMake(1 * kScreenWidth, 0);
//    [self.view addSubview:scrollView];
    [self _fanhuibutton];
}


// 实时计算偏移量达到目的
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    // 获取滑动视图偏移量
    CGPoint point = scrollView.contentOffset;
    NSLog(@"point.x: %f", point.x);
    // 判断情况，将scrollView进行后台的偏移，不需要动画，让用户以为可以循环滑动
    if (point.x <= 0) {
        [scrollView setContentOffset:CGPointMake(21 * kScreenWidth, 0)];
    } else if (point.x >= 22 * kScreenWidth) {
        scrollView.contentOffset = CGPointMake(1 * kScreenWidth, 0);
    }


//       self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"nini"]];
    
//    [self _fanhuibutton];
    
    player = [AVAudioPlayer alloc];
    NSBundle * bundle = [NSBundle mainBundle];
    NSString * path = [bundle pathForResource:@"热田公纪-Childhood Memory (童年的记忆)" ofType:@"mp3"];
    NSURL * url = [NSURL fileURLWithPath:path];
    player = [player initWithContentsOfURL:url error:nil];
}

-(void)_fanhuibutton{
    UIButton * button = [[UIButton alloc]initWithFrame:CGRectMake(20, 44+20, 40, 40)];
    [button setTitle:@"返回" forState: UIControlStateNormal];
    
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [ button setBackgroundColor:[UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1]];
    [button setTitleColor:[UIColor redColor] forState:UIControlStateHighlighted];
    button.layer.cornerRadius = 18;
    button.clipsToBounds = YES;
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    UIButton * button1= [[UIButton alloc]initWithFrame:CGRectMake(20, 200, 40, 40)];
    [button1 setTitle:@"播放" forState: UIControlStateNormal];
    [button1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button1 addTarget:self action:@selector(buttonActiona:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button1];
    
    
}
-(void)buttonAction:(UIButton *)sender{
    
    
    
    [self dismissViewControllerAnimated:YES completion:^(){
        
    }];
    
}

-(void)buttonActiona:(UIButton *)sender{
//    
//        if (sender.selected) {
    [player play];
//        }
//    
//        else{
//         [player pause];
//        }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

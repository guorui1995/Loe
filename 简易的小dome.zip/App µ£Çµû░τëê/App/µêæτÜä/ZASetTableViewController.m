//
//  ZASetTableViewController.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "ZASetTableViewController.h"
#import "GRHomePageViewController.h"
#import "ZZViewController.h"
@interface ZASetTableViewController ()

@end

@implementation ZASetTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"设置";
    self.navigationController.navigationBar.hidden = YES ;
    self.tabBarController.tabBar.hidden = YES ;

    UITableView * tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    // 设置数据源
    tableView.dataSource = self;
    tableView.delegate = self;
    
    [self.view addSubview:tableView];
    
    
    tableView.sectionIndexColor = [UIColor grayColor];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(140, 500, 100, 40)];
    [btn setTitle:@"退出" forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    btn.layer.cornerRadius = 10;
    btn.clipsToBounds = YES;
    [self.view addSubview:btn];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 2;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell * cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    
    if (indexPath.row == 0&& indexPath.section == 0 ) {
        cell.textLabel.text = @"账号管理";
    }
    if (indexPath.row == 1&& indexPath.section == 0) {
        cell.textLabel.text = @"账号安全";
    }
    if (indexPath.row == 0&& indexPath.section == 1 ) {
        cell.textLabel.text = @"通知";
    }
    if (indexPath.row == 1&& indexPath.section == 1) {
        cell.textLabel.text = @"隐私";
    }
    if (indexPath.row == 0&& indexPath.section == 2) {
        cell.textLabel.text = @"意见反馈";
    }
    if (indexPath.row == 1&& indexPath.section == 2) {
        cell.textLabel.text = @"关于";
    }
    if (indexPath.row == 0&& indexPath.section == 3) {
        cell.textLabel.text = @"清除缓存";
        
        
    }
    if (indexPath.row == 1&& indexPath.section == 3) {
        cell.textLabel.text = @"自定义";
    }
    cell.layer.cornerRadius = 18;
    cell.clipsToBounds = YES;
    
    cell.accessoryType =  UITableViewCellAccessoryDisclosureIndicator;
    
    
    return cell;
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if(section==0){
        return 40;
    }
    return 0;
}
-(void)backAction:(UIButton *)sender{
    
    ZZViewController *vc =[ZZViewController sharedInstance];
    
    [self.navigationController pushViewController:vc animated:YES];
}


/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

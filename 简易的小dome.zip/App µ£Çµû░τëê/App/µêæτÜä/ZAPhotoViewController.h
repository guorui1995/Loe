//
//  ZAPhotoViewController.h
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZAMyViewController.h"
@interface ZAPhotoViewController : UIViewController
@property(strong,nonatomic)NSMutableArray * photoArray;


@property(strong,nonatomic)ZAMyViewController *ZAm;

@end

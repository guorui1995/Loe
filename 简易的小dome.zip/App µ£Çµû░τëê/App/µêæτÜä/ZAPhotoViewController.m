//
//  ZAPhotoViewController.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//
#import "ZAPhotoViewController.h"

@interface ZAPhotoViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>
@property(strong,nonatomic)NSMutableArray *arryPhoto;
@property(strong,nonatomic)NSArray * peoplearry;
@property(strong,nonatomic)NSArray * Animationarry;
@property(strong,nonatomic)NSArray * animalarry;
@property(strong,nonatomic)NSArray * arry;

@end
NSString *cellID = @"CollectionViewCellIdentifier";
NSString *headerID=@"headerIdentifier";
@implementation ZAPhotoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.photoArray=[NSMutableArray array];
    for (int i = 1 ; i < 8; i++) {
        NSString * str = [NSString stringWithFormat:@"100%d",i];
        [self.photoArray addObject:str];
    }
    
    UIScrollView *scrollView=[[UIScrollView alloc]initWithFrame:self.view.bounds];
    
    scrollView.contentSize=CGSizeMake(3*[UIScreen mainScreen].bounds.size.width, 0);
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.pagingEnabled = YES;
    scrollView.bounces=NO;
    self.peoplearry=@[@"人物",@"动物",@"动漫",];
    self.animalarry=@[@"dw1",@"dw2",@"dw3",@"dw4",@"dw5",@"dw6",@"dw7",];
    self.Animationarry=@[@"dm1",@"dm2",@"dm3",@"dm4",@"dm5",@"dm6",@"dw7",];
    self.arry=[NSArray arrayWithObjects:self.photoArray,self.animalarry,self.Animationarry ,nil];
    self.arryPhoto=[NSMutableArray array];
    for (int i=0; i<3; i++) {
    
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
     self.title = @"头像选择";
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.itemSize = CGSizeMake([UIScreen mainScreen].bounds.size.width/3-20 , [UIScreen mainScreen].bounds.size.width/3-20);
        //设置头视图大小
        layout.headerReferenceSize=CGSizeMake(self.view.bounds.size.width, 50);
        
        UICollectionView *collectionView=[[UICollectionView alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width*i,0 , [UIScreen mainScreen].bounds.size.width,[UIScreen mainScreen].bounds.size.height )   collectionViewLayout:layout];
        collectionView.dataSource=self;
        collectionView.delegate=self;

        UIImageView *imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0,[UIScreen mainScreen].bounds.size.width , [UIScreen mainScreen].bounds.size.height)];
        imageView.image=[UIImage imageNamed:@"1471438375169"];
        //    注册头视图
        [collectionView registerClass:[UICollectionReusableView class]forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:headerID];
        collectionView.backgroundView=imageView;
        [collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:cellID];
        [scrollView addSubview:collectionView];
        [self.arryPhoto addObject:collectionView];
    }
    [self.view addSubview:scrollView];
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.photoArray.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    UIImageView * imageView = [[UIImageView alloc]init];
    for (int i =0 ; i<3; i++) {
        UICollectionView * uv=self.arryPhoto[i];
        if (uv==collectionView) {
            NSArray * arr1=self.arry[i];
            imageView.image=[UIImage imageNamed:arr1[indexPath.item]];
        }
    }
    cell.backgroundView = imageView;
    
    return cell;
    
}
-(void)collectionView:(UICollectionView *)collectionView
didSelectItemAtIndexPath:( NSIndexPath *)indexPath{
    
    NSLog(@"self.photoArray[indexPath.item] %@",self.photoArray[indexPath.item]);
    ;
    for (int i =0 ; i<3; i++) {
        
        UICollectionView * uv=self.arryPhoto[i];
        if (uv==collectionView) {
            NSArray * arr1=self.arry[i];
            UIImage * image = [UIImage imageNamed:arr1[indexPath.item]];

    self.ZAm.block(image);
            
        }
    }
//把自己本身控制器传过来 重新创建 会重新分配一个地址 跟原来的不一样
     [self.navigationController popToRootViewControllerAnimated:YES];
    
}
//头视图的自定义
-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        UICollectionReusableView *headre=[collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:headerID forIndexPath:indexPath];
        UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(170, -30, 80, 100)];
        for (int i =0 ; i<3; i++) {
            UICollectionView * uv=self.arryPhoto[i];
            if (uv==collectionView) {
                label.text=self.peoplearry[i];
                [headre addSubview:label];
                
                return headre;
            }
            
        }
        
       }
    return nil;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

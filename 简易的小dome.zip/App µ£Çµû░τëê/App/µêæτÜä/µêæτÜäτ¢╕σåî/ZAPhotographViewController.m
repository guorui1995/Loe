//
//  ZAPhotographViewController.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//
#import "ZAPhotographViewController.h"

@interface ZAPhotographViewController ()<UIScrollViewDelegate>
@property(strong,nonatomic)NSMutableArray *array;
@property(strong ,nonatomic)UIScrollView *scrollView;
@property(strong,nonatomic)UIImageView *imageView1;
@property(assign,nonatomic)NSInteger currentIndex;
@end
static const NSInteger IMAGE_NUMBER = 5;
@implementation ZAPhotographViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (int i=0; i<5; i++) {
        UIImageView * imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 64, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-49)];
        imageView.image=[UIImage imageNamed:[NSString stringWithFormat:@"10%d",i]];
        self.imageView1 = imageView ;
        [self.view addSubview:imageView];
        imageView.tag=100+i;
    }
    
    // 添加手势
    [self swipeGesture];
    
}
- (void)swipeGesture
{
    /**轻扫手势--左手势*/
    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeGestureOfLeftClicked:)];
    
    /**手势方向*/
    swipeLeft.direction = UISwipeGestureRecognizerDirectionLeft;
    
    /**轻扫手势--右手势*/
    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeGestureOfRightClicked:)];
    
    swipeRight.direction = UISwipeGestureRecognizerDirectionRight;
    
    [self.view addGestureRecognizer:swipeLeft];
    [self.view addGestureRecognizer:swipeRight];
}
- (void)swipeGestureOfLeftClicked:(UISwipeGestureRecognizer *)swipeGesture
{
    /**左手势为YES*/
    [self transitionAnimation:YES];
}
#pragma mark --向右滑动浏览上一张图片--
- (void)swipeGestureOfRightClicked:(UISwipeGestureRecognizer *)swipeGesture
{
    [self transitionAnimation:NO];
}
- (void)transitionAnimation:(BOOL)isNext
{
    //创建转场动画对象
    CATransition *transition = [[CATransition alloc]init];
    //设置动画类型，
    if (isNext == YES) {
        transition.type     =   @"pageCurl";
        transition.subtype  =   kCATransitionFromRight;
    } else {
        transition.type     =   @"cube";
        transition.subtype  =   kCATransitionFromLeft;
    }
    //设置动画时长，默认为0
    transition.duration=0.8;
    //设置转场后的新视图添加转场动画
    self.imageView1.image=[self transitionImage:isNext];
    //添加动画效果
    [self.imageView1.layer addAnimation:transition forKey:@"Animation"];
    
    
    
}
- (UIImage *)transitionImage:(BOOL)isNext
{
    if (isNext == YES) {
        self.currentIndex = (self.currentIndex + 1) % IMAGE_NUMBER;
    } else {
        self.currentIndex = (self.currentIndex - 1 + IMAGE_NUMBER) % IMAGE_NUMBER;
    }
    
    UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"10%ld",self.currentIndex]];
    
    return image;
}


- (nullable UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    
    CGPoint piont=self.scrollView.contentOffset;
    
    
    
    return [self.view viewWithTag:piont.x/[UIScreen mainScreen].bounds.size.width+100];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

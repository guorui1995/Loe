//
//  ZAMyViewController.h
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef  void(^Myblock)(UIImage * image);
typedef  void(^Myblock1)(NSString *str);
@interface ZAMyViewController : UIViewController
@property(strong,nonatomic)NSMutableArray * nameArry;
@property(strong,nonatomic)UIButton * but;
@property(strong,nonatomic)UILabel *label3;
@property(nonatomic,copy)Myblock block;
@property(nonatomic,copy)Myblock1 intblock;

@end

//
//  ZAMyViewController.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "ZAMyViewController.h"
#import "ZAPhotoViewController.h"
#import "ZAPhotographViewController.h"
#import "ZASetTableViewController.h"
#import "ZAcollectViewController.h"
#define cellID @"cellID"
@interface ZAMyViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    bool _isTapped[1];
}
@property(strong,nonatomic) UITableView *table;
@end

@implementation ZAMyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"view001"]];
    
    //    self.view.backgroundColor=[UIColor groupTableViewBackgroundColor];
    self.title=@"我的信息";
    UIBarButtonItem * rightitem = [[UIBarButtonItem alloc]initWithTitle:@"设置" style:UIBarButtonItemStylePlain target:self action:@selector(setAtion:)];
    UIBarButtonItem * lefttitem = [[UIBarButtonItem alloc]initWithTitle:@"添加好友" style:UIBarButtonItemStylePlain target:self action:@selector(addAtion:)];
    self.navigationItem.rightBarButtonItem = rightitem;
    self.navigationItem.leftBarButtonItem = lefttitem;
    //搭建头像
    [self _myPhoto];
    //搭建图片
    [self _myImage];
    //搭建收藏
    [self  _myCollect];
    //搭建钱包
    [self _myPurse];
    //搭建tableView；
    [self _tableView];
    
}

-(void)_myPhoto{
    UIView * view1 = [[UIView alloc]initWithFrame:CGRectMake(0, 64, [UIScreen mainScreen].bounds.size.width, 100)];
    
    
    UIImageView *imageview = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0,[UIScreen mainScreen].bounds.size.width ,100 )];
    
    
    _but = [[UIButton alloc]initWithFrame:CGRectMake(10, 10, 80, 80)];
    [_but setBackgroundImage:[UIImage imageNamed:@"1001"] forState:UIControlStateNormal];
    __weak typeof(self) weakSelf = self;
    self.block = ^(UIImage * image){
        [weakSelf.but setBackgroundImage:image forState:UIControlStateNormal];
        
    };
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(110,40,200,20)];
    label.text = @"名称:西贝mouth";
    _but.layer.cornerRadius = 40;
    _but.clipsToBounds = YES;
    [_but addTarget:self action:@selector(butAtion:) forControlEvents:UIControlEventTouchUpInside];
    
    [view1 addSubview:imageview];
    [view1 addSubview:_but];
    [view1 addSubview:label];
    
    [self.view addSubview:view1];
    
    
}
-(void)butAtion:(UIButton *)sender{
    ZAPhotoViewController * zp = [[ZAPhotoViewController alloc]init];
    //普通传值 把自己传过去；
    zp.ZAm = self;
    [self.navigationController pushViewController:zp animated:YES];
}

-(void)_myImage{
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0 ,169, [UIScreen mainScreen].bounds.size.width, 50)];
    view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"button001"]];
    view.layer.cornerRadius = 14;
    view.clipsToBounds = YES;
    
    UIButton * imagebut =[[UIButton alloc]initWithFrame:CGRectMake(0 ,0, [UIScreen mainScreen].bounds.size.width, 50)];
    [imagebut addTarget:self action:@selector(imagebutAtion:) forControlEvents:UIControlEventTouchUpInside];
    
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(10,10 ,35, 35)];
    
    imageView.image = [UIImage imageNamed:@"photo1"];
    
    
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(60, 15, 100, 20)];
    label.text=@"相册";
    [view addSubview:label];
    [view addSubview:imageView];
    [view addSubview:imagebut];
    [self.view addSubview:view];
    
}
-(void)imagebutAtion:(UIButton *)sender{
    ZAPhotographViewController * zapg = [[ZAPhotographViewController alloc]init];
    [self.navigationController pushViewController:zapg animated:YES];
}


-(void)_myCollect{
    
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0 ,221, [UIScreen mainScreen].bounds.size.width, 50)];
    view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"button001"]];
    view.layer.cornerRadius = 14;
    view.clipsToBounds = YES;
    
    
    UIButton * collectbut = [[UIButton alloc]initWithFrame:CGRectMake(0 ,0, [UIScreen mainScreen].bounds.size.width, 50)];
    
    [collectbut addTarget:self action:@selector(collectbutAtion:) forControlEvents:UIControlEventTouchUpInside];
    
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(10,10 ,35 , 35)];
    imageView.image = [UIImage imageNamed:@"photo2"];
    
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(60, 15, 100, 20)];
    
    label.text = @"收藏";
    [view addSubview:label];
    [view addSubview:imageView];
    [view addSubview:collectbut];
    [self.view addSubview:view];
    
}
-(void)collectbutAtion:(UIButton *)sender{
    
    [self.navigationController pushViewController:[[ZAcollectViewController alloc]init] animated:YES];
    
   
}
-(void)_myPurse{
    
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0 ,275, [UIScreen mainScreen].bounds.size.width, 50)];
    view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"button001"]];
    view.layer.cornerRadius = 14;
    view.clipsToBounds = YES;
    
    UIButton * Purseimagebut = [[UIButton alloc]initWithFrame:CGRectMake(0 ,0, [UIScreen mainScreen].bounds.size.width, 50)];
    
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(10,10 ,35 , 35)];
    imageView.image = [UIImage imageNamed:@"photo3"];
    
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(60, 15, 100, 20)];
    label.text = @"我的钱包";
    
    UILabel *label2=[[UILabel alloc]initWithFrame:CGRectMake(250,15 ,50 ,20 )];
    label2.text=@"余额:";
    
    _label3=[[UILabel alloc]initWithFrame:CGRectMake(290, 15, [UIScreen mainScreen].bounds.size.width-290, 20)];
    _label3.text=@"1000";
    __weak typeof(self) weakSelf1 = self;
    self.intblock=^(NSString *str){
        NSInteger math=[weakSelf1.label3.text integerValue];
        NSInteger matn1=[str integerValue];
        NSInteger sum=math+matn1;
        weakSelf1.label3.text=[NSString stringWithFormat:@"%ld",sum];
    };
    [view addSubview:label];
    [view addSubview:label2];
    [view addSubview:_label3];
//    [view addSubview:label];
    [view addSubview:imageView];
    [view addSubview:Purseimagebut];
    [self.view addSubview:view];
    
    
}
-(void)_tableView{
    _table = [[UITableView alloc]initWithFrame:CGRectMake(0, 350, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-350-49) style:UITableViewStyleGrouped];
    UIImageView *imagview = [[UIImageView alloc]init];
    imagview.image = [UIImage imageNamed:@"view001"];
    _table.backgroundView = imagview;
    _table.dataSource = self;
    _table.delegate = self;
    [_table registerClass:[UITableViewCell class] forCellReuseIdentifier:cellID];
    self.nameArry = [NSMutableArray arrayWithObjects:@"好友1", @"好友2", @"好友3", @"好友4", @"好友5", @"好友6", @"好友7", @"好友8", @"好友9", nil];
    
    [self.view addSubview:_table];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (_isTapped[0]) {
        return 0;
    }
    
    return self.nameArry.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellID forIndexPath:indexPath];
    NSString *str = self.nameArry[indexPath.row];
    cell.textLabel.text = str;
    //    UIImageView *imagview=[[UIImageView alloc]init];
    //    imagview.image=[UIImage imageNamed:@"button001"];
    //    cell.backgroundView=imagview;
    cell.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"button001"]];
    cell.layer.cornerRadius = 14;
    cell.clipsToBounds = YES;
    return cell;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [btn setTitle:@"我的好友" forState:UIControlStateNormal];
    //    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"button001"] forState:UIControlStateNormal];
    btn.layer.cornerRadius = 14;
    btn.clipsToBounds = YES;
    
    [btn addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    return btn;
}
//自动收近；
//-(NSInteger)tableView:(UITableView *)tableView indentationLevelForRowAtIndexPath:(NSIndexPath *)indexPath{
//    NSUInteger row = [indexPath row];
//    return row;
//}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 50;
}
-(void)buttonAction:(UIButton *)sender{
    
    
    _isTapped[0] = !_isTapped[0];
    
    NSIndexSet * set = [NSIndexSet indexSetWithIndex:0];
    [self.table reloadSections:set withRowAnimation:UITableViewRowAnimationFade];
    
}

-(void)setAtion:(id)sender{
    
     [self.navigationController pushViewController:[[ZASetTableViewController alloc]init] animated:YES];
    
}
//添加按钮的
-(void)addAtion:(id)sender{
    UIAlertController * alertView = [UIAlertController alertControllerWithTitle:@"添加好友" message:@"输入好友名字" preferredStyle:UIAlertControllerStyleAlert];
    
    [alertView addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        
    }];
    UIAlertAction * alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        UITextField *textfield = alertView.textFields[0];
        [self.nameArry addObject:textfield.text];
        
        NSIndexSet * set = [NSIndexSet indexSetWithIndex:0];
        [self.table reloadSections:set withRowAnimation:UITableViewRowAnimationFade];
    }];
    
    UIAlertAction * alertAction2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [alertView addAction:alertAction1];
    [alertView addAction:alertAction2];
    [self presentViewController:alertView animated:YES completion:nil];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

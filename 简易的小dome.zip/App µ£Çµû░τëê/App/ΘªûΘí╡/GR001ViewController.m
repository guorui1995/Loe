//
//  GR001ViewController.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//


#import "GR001ViewController.h"
#import "GR002ViewController.h"
#define kScreenWidth     [UIScreen mainScreen].bounds.size.width
#define kScreenHeight     [UIScreen mainScreen].bounds.size.height
@interface GR001ViewController ()<UIScrollViewDelegate>

@property(nonatomic,strong)UIScrollView * scrollView;

@end

@implementation GR001ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 搭建界面
    [self createView];
    
    
    // 搭建按钮界面
    [self createButton];
    self.ZAmyvc.view;
}



-(void)createView{
    self.scrollView = [[ UIScrollView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    self.scrollView.backgroundColor = [UIColor yellowColor];
    
    self.scrollView.maximumZoomScale = 2.5;
    self.scrollView.minimumZoomScale = 0.5;
    self.scrollView.delegate = self ;
    [self.view addSubview:self.scrollView];
    
    UIImageView * imge = [[UIImageView alloc]initWithFrame:self.view.bounds];
    
    
    imge.image = [UIImage imageNamed:@"4"];
    imge.tag = 101 ;
    [_scrollView addSubview:imge];
    
    
    
}

-(void)createButton{
    UITapGestureRecognizer * tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureAction:)];
    tapGes.numberOfTapsRequired = 2;
    [self.scrollView addGestureRecognizer:tapGes];
    
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0,kScreenHeight-49 , kScreenWidth, 49)];
    
    view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:view];
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0 ,0 ,kScreenWidth/3, 49)];
    
    [btn setTitle:@"返回上一页" forState:UIControlStateNormal ];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [btn  addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:btn];
    
    UIButton * btn1 = [[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth/3 ,0 ,kScreenWidth/3, 49)];
    
    [btn1 setTitle:@"全景" forState:UIControlStateNormal ];
    [btn1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [btn1  addTarget:self action:@selector(btnAction1:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:btn1];
    
    
    UIButton * btn2 = [[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth/3*2 ,0 ,kScreenWidth/3, 49)];
    
    [btn2 setTitle:@"完成任务" forState:UIControlStateNormal ];
    [btn2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [btn2  addTarget:self action:@selector(btnAction3:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:btn2];
    
    
    
}


- (void)tapGestureAction:(UITapGestureRecognizer *)tap {
    
    
    
    if (self.scrollView.zoomScale > 1.0) {
        
        [self.scrollView setZoomScale:1.0 animated:YES];
    } else if (self.scrollView.zoomScale < 1.0) {
        
        [self.scrollView setZoomScale:1.0 animated:YES];
    } else {
        
        [self.scrollView setZoomScale:2.0 animated:YES];
    }
    
}

- (nullable UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    // 指定将要缩放的视图是对应的imageView
    return [self.view viewWithTag:101];
}

-(void)btnAction:(UIButton *)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)btnAction1:(UIButton *)sender{
    
    GR002ViewController * vc =[[GR002ViewController alloc]init];
    [self presentViewController:vc animated:YES completion:nil];
    
}
-(void)btnAction3:(UIButton *)sender{
    // 创建弹窗
    [self alertViewTest];
}

- (void)alertViewTest {
    _rmb = arc4random_uniform(100);
     NSString * str1 = [NSString stringWithFormat:@"%ld",_rmb];
    self.ZAmyvc.intblock(str1);
    NSString * str  = [NSString stringWithFormat:@"本次获得的志愿币为:%ld",_rmb];
    UIAlertController * alertView = [UIAlertController alertControllerWithTitle:@"您的任务已完成" message:str  preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    UIAlertAction * alertAction2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    
    
    [alertView addAction:alertAction1];
    [alertView addAction:alertAction2];
    [self presentViewController:alertView animated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

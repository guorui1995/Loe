//
//  GR001ViewController.h
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZAMyViewController.h"
@interface GR001ViewController : UIViewController
@property(nonatomic,assign)NSInteger rmb;
@property(nonatomic,strong)ZAMyViewController *ZAmyvc;

@end

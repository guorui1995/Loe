//
//  GR002ViewController.m
//  App
//
//  Created by lx on 16/8/25.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "GR002ViewController.h"
#define kScreenWidth     [UIScreen mainScreen].bounds.size.width
#define kScreenHeight     [UIScreen mainScreen].bounds.size.height
@interface GR002ViewController ()
@property(nonatomic,strong) UIScrollView * scrollView;
@end

@implementation GR002ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    UIImageView * image = [[UIImageView alloc]initWithFrame:[UIScreen mainScreen].bounds];
//    image.image = [UIImage imageNamed:@"view001"];
//    [self.view addSubview:image];
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0  ,64 ,80, 49)];
    
    [btn setTitle:@"返回" forState:UIControlStateNormal ];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [btn  addTarget:self action:@selector(btnAction2:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    [self scroww];
}
-(void)btnAction2:(UIButton *)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)scroww{
    
    self.scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 150, 375, 400)];
    
    [self.view addSubview:self.scrollView];
    
    self.scrollView.contentSize = CGSizeMake(1800, 0);
    
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 1800, 400)];
    image.image = [UIImage imageNamed:[NSString stringWithFormat:@"quanjing"]];
    
    [self.scrollView addSubview:image];
    


}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

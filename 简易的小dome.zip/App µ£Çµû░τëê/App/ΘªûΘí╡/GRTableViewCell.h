//
//  GRTableViewCell.h
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRTableViewCell : UITableViewCell
// cell图片
@property(nonatomic,strong)UIImageView * cellImage;


//接收按钮
@property(nonatomic,strong) UIButton * recBtn;

//已接收按钮
@property(nonatomic,strong) UIButton * didBtn;


@end

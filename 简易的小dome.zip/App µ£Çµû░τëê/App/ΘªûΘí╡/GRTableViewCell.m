//
//  GRTableViewCell.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "GRTableViewCell.h"

#define kScreenWidth     [UIScreen mainScreen].bounds.size.width
#define kScreenHeight     [UIScreen mainScreen].bounds.size.height
@implementation GRTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        // 创建cell中 的图片
        self.cellImage = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, (kScreenWidth)/3-60, (kScreenHeight)/7-50)];
        
        self.cellImage.layer.cornerRadius = 20;
        self.cellImage.clipsToBounds = YES;
        
        [self.contentView addSubview:self.cellImage];
        
        // cell的背景图
        UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake((kScreenWidth)/3, 0, (kScreenWidth)/3*2, (kScreenHeight)/7-10) ];
        
        
        [self.contentView addSubview:imageView];
        
        UILabel * lab = [[UILabel alloc]initWithFrame:CGRectMake(10 , 5, (kScreenWidth)/3*2, (kScreenHeight)/7-30-10)];
        
        lab.text =@"求助的的内容";
        
        
        [imageView addSubview:lab];
        
        
        // 创建距离按钮
        
        
        //创造时间文本标签
        
        UILabel * celllabel = [[UILabel alloc]initWithFrame:CGRectMake((kScreenWidth)/3,(kScreenHeight)/9-30 , 40, 20)];
        int value = (arc4random()%24);
        celllabel.text = [NSString stringWithFormat:@"%d:%d",value,arc4random_uniform(60)];
        celllabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:celllabel];
        
        
        //创建接收按钮
        _recBtn = [[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth-140, (kScreenHeight)/9-30, 70, 20)];
        
        [_recBtn setTitle:@"接收" forState:UIControlStateNormal];
        [_recBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_recBtn setTitleColor:[UIColor greenColor] forState:UIControlStateSelected];
        _recBtn.titleLabel.font = [UIFont systemFontOfSize:15];
        [_recBtn addTarget:self action:@selector(recBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_recBtn];
        
        //创建已接受按钮
        _didBtn = [[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth-70, (kScreenHeight)/9-30, 70, 20)];
        [_didBtn setTitle:@"已接收" forState:UIControlStateNormal];
        [_didBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        _didBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        [_didBtn addTarget:self action:@selector(recBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_didBtn];
    }
    
    
    
    
    return  self ;
    
}



//接收按钮的方法
-(void)recBtnAction:(UIButton *)sender{
    sender.selected = !sender.selected;
}



@end

//
//  GRHomePageViewController.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "GRHomePageViewController.h"
#import "GRTableViewCell.h"
#import "GR001ViewController.h"
#define kScreenWidth     [UIScreen mainScreen].bounds.size.width
#define kScreenHeight     [UIScreen mainScreen].bounds.size.height
#define cellID  @"cellIdentifire"
@interface GRHomePageViewController () <UITableViewDataSource,UITableViewDelegate>
//计数
@property(nonatomic,assign)NSInteger num;
// cell的行数
@property(nonatomic,strong)NSArray * cellArr;
// cell的图片
@property(nonatomic,strong)NSMutableArray * cellImageArr;



@property(nonatomic,strong)NSMutableArray * isRec;
@end

@implementation GRHomePageViewController
{
    int a ;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _cellArr = [NSArray array];
    _cellImageArr = [NSMutableArray array];
    _isRec = [NSMutableArray array];
    _cellArr = @[@"1",@"1",@"1",@"1",@"0",@"0",@"0",@"0",@"0",@"0",@"0",@"0",];
    _num = 4 ;
    a = 0 ;
    // 搭建导航栏视图
    [self _setUpNavigationView];
    // 搭建显示内容的表视图
    [self _setUpTableView];
    
}

// 导航栏的搭建
-(void)_setUpNavigationView{
    //创建导航栏右边的按钮
    
    UIImageView * imageView =[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 44)];
    
    imageView.backgroundColor = [UIColor colorWithRed:0.25 green:0.25 blue:0.25 alpha:1];
    UINavigationBar * bar = self.navigationController.navigationBar;
    
    [bar addSubview:imageView];
    
    UILabel * titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(kScreenWidth/2-50, 0, 100, 44)];
    titleLabel.text = @"首页";
    titleLabel.font = [UIFont boldSystemFontOfSize:20];
    titleLabel.textColor = [UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    self.navigationItem.titleView = titleLabel;
    
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 44, 44);
    [button setTitle:@"刷新" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    [button setTitleColor:[UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(ButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    button.tag = _num ;
    UIBarButtonItem * Item = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = Item;
    
    //创建导航栏左边的文本标签
    [self makeLabel];
    
    
}




// 表视图的搭建
-(void)_setUpTableView{
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight) style:(UITableViewStylePlain)];
    _tableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"010ec5569a23be32f87574beb12a7f"]];
    
    _tableView.delegate = self ;
    _tableView.dataSource = self ;
    [_tableView registerClass:[GRTableViewCell class] forCellReuseIdentifier:cellID];
    _tableView.rowHeight =(kScreenHeight)/11;
    [self.view addSubview:_tableView];
    _tableView.pagingEnabled = NO ;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
    for (int i = 0; i<4; i++) {
        UIImage *  image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.jpg",i+10]];
        [_cellImageArr addObject:image];
        
    }
    //系统自带的下拉刷新方法
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    //触发方法
    [refreshControl addTarget:self action:@selector(refreshClick:) forControlEvents:UIControlEventValueChanged];
    
    [self.tableView addSubview:refreshControl];
    //开始刷新
    [refreshControl beginRefreshing];
    //调用方法
    [self refreshClick:refreshControl];

    
    
    
}
- (void)refreshClick:(UIRefreshControl *)refreshControl {
    a++ ;
    _num++;
    [self makeLabel];
    UIImage * image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld.jpg",_num+9]];
    [_cellImageArr insertObject:image atIndex:0];
    
   
    
    
    // 结束刷新
    [refreshControl endRefreshing];
     [_tableView reloadData];
 
  
}


// 刷新按钮的触发方法
-(void)ButtonAction:(UIButton *)sender{
    sender.highlighted = ! sender.highlighted;
    a++ ;
    _num++;
    [self makeLabel];
    UIImage * image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld.jpg",_num+9]];
    [_cellImageArr insertObject:image atIndex:0];
    
    [_tableView reloadData];
    
}
-(void)makeLabel{
    UILabel * leftLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 100, 44)];
    leftLabel.text = [NSString stringWithFormat:@"消息(%ld)",_num];
    
    leftLabel.textColor  = [UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1];
    leftLabel.textAlignment = NSTextAlignmentLeft ;
    
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftLabel];
    self.navigationItem.leftBarButtonItem = leftItem;
    
}

// 返回的单元格行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _cellImageArr.count;
}

//创建的单元格样式
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    GRTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellID forIndexPath:indexPath];
    cell.backgroundColor = [UIColor clearColor];
    
   
    if (indexPath.row == a || indexPath.row == a+2) {
        [cell.didBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        cell.didBtn.enabled = YES ;
        cell.recBtn.enabled = YES ;
    }else{
        [cell.didBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        cell.recBtn.selected = NO ;
        
    }
    cell.cellImage.image = _cellImageArr[indexPath.row];
    
    UIButton *  distanceBtn = [[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth-70, 10, 70, 20)];
    
    [distanceBtn setTitle:@"距离" forState:UIControlStateNormal];
    [distanceBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    distanceBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    [distanceBtn addTarget:self action:@selector(distanceBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [cell addSubview:distanceBtn];
    return cell;
    
    
    
}

// 距离按钮的方法
-(void)distanceBtnAction:(UIButton *)sender{
    GR001ViewController * vc =[[GR001ViewController alloc]init];
    vc.ZAmyvc=self.zamyv;
    [self presentViewController:vc animated:YES completion:nil];
    
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    _num--;
    a--;
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // 开始tableView内容的更新，需要和结束方法成套的使用，有开始更新就一定要有结束更新（否则不会产生效果），在方法之间的更新，一定要更新数据源
        [tableView beginUpdates];
        
        // 1.改变数据源
        [self.cellImageArr removeObjectAtIndex:indexPath.row];
        
        // 2.改变界面元素---》对表视图中的数据进行刷新
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        
        
        
        [tableView endUpdates];
    }
    
    [self makeLabel];
}
@end


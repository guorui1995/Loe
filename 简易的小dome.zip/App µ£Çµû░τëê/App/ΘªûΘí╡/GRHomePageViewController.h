//
//  GRHomePageViewController.h
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZAMyViewController.h"
@interface GRHomePageViewController : UIViewController
@property(nonatomic,strong)ZAMyViewController *zamyv;
@property(nonatomic,strong)UITableView * tableView;
@end

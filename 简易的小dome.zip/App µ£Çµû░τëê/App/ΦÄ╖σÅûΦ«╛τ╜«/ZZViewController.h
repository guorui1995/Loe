//
//  ZZViewController.h
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZZViewController : UIViewController
@property(nonatomic,strong)NSString * account ;
@property(nonatomic,strong)NSString * password ;

+ (instancetype)sharedInstance;
@end

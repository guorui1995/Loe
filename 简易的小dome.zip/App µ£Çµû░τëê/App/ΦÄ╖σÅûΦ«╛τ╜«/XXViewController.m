//
//  XXViewController.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//

#import "XXViewController.h"
#import "ZZViewController.h"
@interface XXViewController ()

@end
@implementation XXViewController
{
    UIImageView *view2;
    UITextField * sb;
    UITextField * song;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    sb.text = @"";
    song.text = @"";
    view2 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    view2.image = [UIImage  imageNamed:@"55.png"];
    [self.view addSubview:view2];
    
    sb = [[UITextField alloc]initWithFrame:CGRectMake(30, 200, 315, 45)];
    sb.backgroundColor = [UIColor whiteColor];
    sb.placeholder = @"请输入账号";
    sb.layer.cornerRadius = 14;
    sb.clipsToBounds = YES;
    [self.view addSubview:sb];
    //
    song  = [[UITextField alloc]initWithFrame:CGRectMake(30, 260, 315, 45)];
    song.backgroundColor = [UIColor whiteColor];
    song.placeholder = @"请输入密码";
    song.layer.cornerRadius = 14;
    song.clipsToBounds = YES;
    //加密
    song.secureTextEntry = YES ;
    [self.view addSubview:song];
    
    UIButton * qing = [UIButton buttonWithType:UIButtonTypeSystem];
    qing.frame = CGRectMake(20, 360,335, 45);
    [qing setTitle:@"下一步"forState:UIControlStateNormal];
    qing.backgroundColor = [UIColor colorWithRed:0 green:0.8 blue:0.9 alpha:1];
    qing.titleLabel.font = [UIFont systemFontOfSize:18];
    qing.layer.cornerRadius = 14;
    qing.clipsToBounds = YES;
    [qing setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [qing addTarget:self action:@selector(qingAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:qing];
    
    UIButton * bu = [UIButton buttonWithType:UIButtonTypeSystem];
    bu.frame = CGRectMake(10,40 ,40 ,40 );
    [bu setTitle:@"返回" forState:UIControlStateNormal];
    [bu setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [bu addTarget:self action:@selector(tsst:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bu];
    
    
    
    
}
-(void)qingAction:(UIButton *)sender{
    ZZViewController * vc = [ZZViewController sharedInstance];
    vc.password = song.text;
    vc.account = sb.text;
    
    UIAlertController * alertView = [UIAlertController alertControllerWithTitle:@"注册成功" message:@"请返回登录界面" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        
        [self.navigationController popToViewController:vc animated:YES];
        
        
    }];
    
    
    [alertView addAction:alertAction1];
    
    [self presentViewController:alertView animated:YES completion:nil];
    
    
}
-(void)tsst:(UIButton *)sender{
    
    ZZViewController * vc = [ZZViewController sharedInstance];
    [self.navigationController popToViewController:vc animated:YES];
    
    //    vc.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

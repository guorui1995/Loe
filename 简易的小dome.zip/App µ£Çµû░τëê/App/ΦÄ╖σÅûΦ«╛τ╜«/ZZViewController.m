//
//  ZZViewController.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//


#import "ZZViewController.h"
#import "GRViewController.h"
#import "ViewController.h"
#import "XXViewController.h"
#define kScreenWidth     [UIScreen mainScreen].bounds.size.width
#define kScreenHeight     [UIScreen mainScreen].bounds.size.height

@interface ZZViewController ()

@property(nonatomic,strong)UITextField * sb;
@property(nonatomic,strong)UITextField * song;
@end

@implementation ZZViewController

{
    UIImageView *view1;
    NSTimer * timer ;
    int timeNum ;
    NSMutableArray *imageArray;
    UIImageView *imageView;
    UIView * view;
}
+ (instancetype)sharedInstance {
    static ZZViewController * sharedInstance = nil;
    // 判断sharedInstance这个对象是否存在，如果存在那么我就直接return掉，如果不存在，就进行初始化操作
    if (sharedInstance == nil) {
        // alloc init,在这里面的方法，会保证只会alloc一次
        sharedInstance = [[self alloc] init];
    }
    return sharedInstance;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    
    
    
    
    view1 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    view1.image = [UIImage  imageNamed:@"54.png"];
    [self.view addSubview:view1];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(reKeyBoard)];
    [self.view addGestureRecognizer:tap];
    
    //登录界面头像
    UIButton * bing = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 100, 100 )];
    UIImage * ing = [UIImage imageNamed:@"98.jpg"];
    UIImageView * ong = [[UIImageView alloc]initWithFrame:CGRectMake(145,100 , 100, 100)];
    ong.image = ing;
    ong.layer.cornerRadius = 50;
    ong.clipsToBounds = YES;
    [bing setImage:ong.image forState:UIControlStateNormal];
    
    [self.view addSubview:ong];
    [ong addSubview:bing];
    ong.userInteractionEnabled = YES;
    //
    
    _sb = [[UITextField alloc]initWithFrame:CGRectMake(30, 245, 315, 45)];
    _sb.backgroundColor = [UIColor whiteColor];
    _sb.layer.cornerRadius = 14;
    _sb.clipsToBounds = YES;
    _sb.placeholder = @"登录账号";
    [self.view addSubview:_sb];
    //
    _song = [[UITextField alloc]initWithFrame:CGRectMake(30, 300, 315, 45)];
    _song.backgroundColor = [UIColor whiteColor];
    
    _song.layer.cornerRadius = 14;
    _song.clipsToBounds = YES;
    _song.placeholder = @"密码";
    _song.secureTextEntry = YES ;
    [self.view addSubview:_song];
    
    UIButton * bo = [UIButton buttonWithType:UIButtonTypeSystem];
    bo.frame = CGRectMake(30,350 ,80 ,40 );
    [bo setTitle:@"忘记密码?" forState:UIControlStateNormal];
    [bo setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.view addSubview:bo];
    
    
    
    
    
    UIButton * btt = [UIButton buttonWithType:UIButtonTypeSystem];
    btt.frame = CGRectMake(280,350 ,80 ,40 );
    [btt setTitle:@"注册账号" forState:UIControlStateNormal];
    [btt setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btt addTarget:self action:@selector(bttAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btt];
    
    UIButton * qing = [UIButton buttonWithType:UIButtonTypeSystem];
    qing.frame = CGRectMake(30, 450, 315, 45);
    [qing setTitle:@"登录"forState:UIControlStateNormal];
    qing.backgroundColor = [UIColor colorWithRed:0 green:0.8 blue:0.9 alpha:1];
    qing.titleLabel.font = [UIFont systemFontOfSize:18];
    qing.layer.cornerRadius = 14;
    qing.clipsToBounds = YES;
    [qing setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [qing addTarget:self action:@selector(teet:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:qing];
    
    
}

- (void)reKeyBoard
{
    [self.view endEditing:YES];
    
    
}
-(void)bttAction:(UIButton *)sender{
    XXViewController * vc =[[XXViewController alloc]init];
    
    
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)teet:(UIButton *)sender{
    
    if ([_sb.text isEqualToString: _account] && [_song.text isEqualToString:_password]) {
        timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(timerAction:) userInfo:nil repeats:YES];
        timeNum = 0;
        imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width,  [UIScreen mainScreen].bounds.size.height)];
        imageView.image =[UIImage imageNamed:@"a0"];
        [self.view addSubview:imageView];
    }else{
        UIAlertController * alertView = [UIAlertController alertControllerWithTitle:@"密码或账号错误" message:@"请重新输入" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction * alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [alertView addAction:alertAction1];
        
        [self presentViewController:alertView animated:YES completion:nil];
        _sb.text  = @"";
        _song.text = @"";
        
    }
    
    
}

-(void)timerAction:(NSTimer *)time{
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        UIImage *image=[UIImage imageNamed: [NSString stringWithFormat:@"a%d",timeNum]];
        CATransition *transition = [[CATransition alloc]init];
        imageView.image = image ;
        
        //动画类型
        transition.type = @"rippleEffect";
        
        //动画执行方向
        transition.subtype = kCATransitionFromBottom;
        
        transition.duration = 2;
        
        [imageView.layer addAnimation:transition forKey:@"Animation"];
        
    });
    
    
    
    if (timeNum == 3) {
        GRViewController * vc = [[GRViewController alloc]init];
        [self presentViewController:vc  animated:YES completion:nil];
        vc.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    }
    
    
    timeNum++;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

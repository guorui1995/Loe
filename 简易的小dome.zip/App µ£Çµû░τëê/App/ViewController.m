//
//  ViewController.m
//  App
//
//  Created by lx on 16/8/24.
//  Copyright © 2016年 lx. All rights reserved.
//
#import "ViewController.h"
#import "ZZViewController.h"
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
@interface  ViewController()
@property (nonatomic ,strong) NSArray * numberArr;
@property (nonatomic ,strong) UIButton * but;
@property (nonatomic ,strong) UITextField  * textField;
@property (nonatomic ,strong) UIView  * dropV;

@end

@implementation ViewController{
    NSInteger a;
    int b ;
    NSString * str;
    NSString * passWork;

}
- (void)viewDidLoad {
    [super viewDidLoad];
    a = 0 ;
    //self.view.backgroundColor=[UIColor colorWithRed:0 green:0.2 blue:0.4 alpha:1];
    passWork = @"2016";
    self.navigationController.navigationBar.hidden = YES ;
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"43"] ];
    UIButton * bo = [UIButton buttonWithType:UIButtonTypeSystem];
    bo.frame = CGRectMake(290, kScreenHeight-130, 40,20 );
    [bo setTitle:@"取消" forState:UIControlStateNormal];
    [bo addTarget:self action:@selector(deleteNumlock) forControlEvents:UIControlEventTouchUpInside];
    [bo setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.view addSubview:bo];
    
    UIButton * sheZhi = [UIButton buttonWithType:UIButtonTypeSystem];
    sheZhi.frame = CGRectMake(40, kScreenHeight-130, 60,20 );
    [sheZhi setTitle:@"紧急拨号" forState:UIControlStateNormal];
    [sheZhi setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.view addSubview:sheZhi];

    //创建内容视图
    [self _configureNavigationContentView];
    //创建密码文本框
    [self initSmallDrop];
}
- (void)deleteNumlock
{
    b = 0;
    a = 0;
    [self initSmallDrop];
}
- (void)initSmallDrop
{
    self.dropV = [[UIView alloc]initWithFrame:CGRectMake(kScreenWidth/2-55, 100, 110, 12)];
    _dropV.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_dropV];
    for (int i = 0; i < 4; i ++)
    {
        UIImageView * dropImg = [[UIImageView alloc] initWithFrame:CGRectMake(i * 32, 0, 12, 12)];
        [_dropV addSubview:dropImg];
        dropImg.tag = 2000 + i;
        [dropImg setImage:[UIImage imageNamed:@"44"]];
    }
}

- (void)_configureNavigationContentView {

    self.numberArr = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"",@"0"];

    for (int i = 0; i < 11; i++) {
        //当i=9时，没有按钮
        if (i!= 9) {

            self.but = [[UIButton alloc]initWithFrame:CGRectMake(35+(50+70) * (i%3), 150+(70+50) * (i/3), 70, 70)];

            //设计按钮普通状态的背景颜色
            [self.but setBackgroundImage:[UIImage imageNamed:@"40"] forState:UIControlStateNormal];
            //设计按钮高亮状态的背景颜色
            [self.but setBackgroundImage:[UIImage imageNamed:@"41"] forState:
             UIControlStateHighlighted];
            //切圆
            self.but.layer.cornerRadius = 35;
            self.but.clipsToBounds = YES;
            //字体大小
            self.but.titleLabel.font = [UIFont systemFontOfSize:32];
            //设计按钮标题
            [self.but setTitle:self.numberArr[i] forState:UIControlStateNormal];
            //设计按钮标题颜色
            [self.but setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            [self.but addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
            //设计按钮tag值
            self.but.tag = i+100;
            [self.view addSubview:self.but];
        }



    }
}


-(void)btnAction:(UIButton *)sender{
    b++;
    if (b < 5) {
        UIImageView * dropImg = [[UIImageView alloc] initWithFrame:CGRectMake((b-1) * 32, 0, 12, 12)];
        [_dropV addSubview:dropImg];
        
        [dropImg setImage:[UIImage imageNamed:@"drop_selected"]];
    }
    if (b==1) {
        
        if (sender.tag-100+1 < 10) {
            
            a = sender.tag-100+1+(a * 10);
            str = [NSString stringWithFormat:@"%ld", a];
        }else if(sender.tag-100+1 == 11){
            a = 0+(a * 10);
            str = [NSString stringWithFormat:@"%ld", a];
            
            
            
        }
            }else if (b==2) {
        
        if (sender.tag-100+1 < 10) {
            
            a = sender.tag-100+1+(a * 10);
            str = [NSString stringWithFormat:@"%ld",a];
        }else if(sender.tag-100+1 == 11){
            a = 0+(a * 10);
            str = [NSString stringWithFormat:@"%ld",a];
            
        }
           }else if (b==3) {
        
        if (sender.tag-100+1 < 10) {
            
            a = sender.tag-100+1+(a * 10);
            str = [NSString stringWithFormat:@"%ld",a];
        }else if(sender.tag-100+1 == 11){
            a = 0+(a * 10);
            str = [NSString stringWithFormat:@"%ld",a];
            
            
            
        }
           }else if (b==4) {
        
        if (sender.tag-100+1 < 10) {
            
            a = sender.tag-100+1+(a*10);
            str = [NSString stringWithFormat:@"%ld",a];
        }else if(sender.tag-100+1 == 11){
            a = 0+(a*10);
            str = [NSString stringWithFormat:@"%ld",a];
            
        }
                if ([str isEqualToString:passWork]) {
            //弹出模态页面
                    ZZViewController * vc = [ZZViewController sharedInstance];
                    
                    
                    [self.navigationController pushViewController:vc animated:YES];

            
        }else{
            str = @"" ;
            
            
        }
        [self initSmallDrop];
        b = 0;
        a = 0 ;
    }
    
    
    
   }

@end




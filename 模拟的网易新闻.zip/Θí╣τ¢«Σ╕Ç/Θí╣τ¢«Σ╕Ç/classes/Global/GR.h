//
//  GR.h
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GRNewsViewController.h"
@interface GR : UITabBarController

@end

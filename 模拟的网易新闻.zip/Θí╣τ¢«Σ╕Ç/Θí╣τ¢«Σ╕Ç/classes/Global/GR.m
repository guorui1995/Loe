//
//  GR.m
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GR.h"
#import "GRFoundViewController.h"
#import "GRLiscentViewController.h"
#import "GRMeViewController.h"
#import "GRMCollectionViewCell.h"
#import "GRReadViewController.h"
#import "GRViewController.h"

#define tabBarTintColor [UIColor colorWithRed:166.0 / 255.0 green:26.0 / 255.0 blue:30.0 / 255.0 alpha:1]
@interface GR ()

@end

@implementation GR

- (void)viewDidLoad {
    [super viewDidLoad];
    // 配置视图控制器
    [self _configureViewControllers];
    
    self.tabBar.barTintColor = [ UIColor blackColor];
}

-(void)_configureViewControllers{
// 创建最外层的视图控制器
    //发现
    GRFoundViewController * vc2 = [[GRFoundViewController alloc]init];
    UITabBarItem * Item2 = [[UITabBarItem alloc]initWithTitle:@"发现" image:[UIImage imageNamed:@"tabbar_icon_found_normal@2x" ] tag:101];
    vc2.tabBarItem = Item2 ;
    //阅读
    GRLiscentViewController * vc4 = [[GRLiscentViewController alloc]init];
    UITabBarItem * Item4 = [[UITabBarItem alloc]initWithTitle:@"阅读" image:[UIImage imageNamed:@"tabbar_icon_reader_normal@2x" ] tag:101];
    vc4.tabBarItem = Item4 ;
    //我的
    GRMeViewController * vc5 = [[GRMeViewController alloc]init];
    UITabBarItem * Item5 = [[UITabBarItem alloc]initWithTitle:@"我的" image:[UIImage imageNamed:@"tabbar_icon_me_normal@2x" ] tag:101];
    vc5.tabBarItem = Item5 ;
    //新闻
    GRNewsViewController * vc1 = [[GRNewsViewController alloc]init];
    UITabBarItem * Item1 = [[UITabBarItem alloc]initWithTitle:@"新闻" image:[UIImage imageNamed:@"tabbar_icon_news_normal@2x" ] tag:101];
    
    
    vc1.tabBarItem = Item1 ;
   
    //视听
    GRReadViewController * vc3 = [[GRReadViewController alloc]init];
    UITabBarItem * Item3 = [[UITabBarItem alloc]initWithTitle:@"视听" image:[UIImage imageNamed:@"tabbar_icon_media_normal@2x" ] tag:101];
    vc3.tabBarItem = Item3 ;
    NSArray * vcArr = @[vc1,vc2,vc3,vc4,vc5];
     //构建管理五组子页面的五个导航栏控制器
    NSMutableArray * nagtArr = [NSMutableArray array];
    for (UIViewController * vc in vcArr) {
        GRViewController * nagt = [[GRViewController alloc]initWithRootViewController:vc];
        [nagtArr addObject:nagt];
    }
    // 给标签栏控制器的viewController赋值
    self.viewControllers = nagtArr ;
    // 选中颜色
    self.tabBar.tintColor = tabBarTintColor;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

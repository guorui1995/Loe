//
//  GRViewController.m
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRViewController.h"

@interface GRViewController ()

@end

@implementation GRViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // 设置导航栏的背景色
    self.navigationBar.barTintColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"top_navigation_background@2x.png"]];
}
// 返回状态栏样式 ，将状态栏设置为白色
- (UIStatusBarStyle)preferredStatusBarStyle {
    
    return UIStatusBarStyleLightContent;
}

//当用导航栏push到视图中时 进入此方法
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    
    // 在这里，push时隐藏导航栏和标签栏
    if (self.viewControllers.count >= 1) {
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:self action:NULL];
        self.navigationBar.hidden = YES;
        self.tabBarController.tabBar.hidden = YES;
    }
    
    [super pushViewController:viewController animated:animated];
}

// 当pop到原来的导航栏时进入此方法
- (NSArray<UIViewController *> *)popToRootViewControllerAnimated:(BOOL)animated {
    //在这里显示导航栏和标签栏
    if (self.viewControllers.count <= 2) {
        self.navigationBar.hidden = NO;
        self.tabBarController.tabBar.hidden = NO;
    }
    
    return [super popToRootViewControllerAnimated:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

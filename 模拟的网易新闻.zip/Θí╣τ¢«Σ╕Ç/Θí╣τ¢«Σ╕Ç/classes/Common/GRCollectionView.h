//
//  GRCollectionView.h
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <UIKit/UIKit.h>

// 创建一个Block
typedef void(^ConfigurationInformation)();
// 签订集合视图的数据源 和 代理 和布局代理
@interface GRCollectionView : UICollectionView<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>
// 声明一个瀑布布局
@property(nonatomic,strong)UICollectionViewFlowLayout * flowLayout;

// 声明一个带frame和block参数的实例方法
-(instancetype)initWithFrame:(CGRect)frame collectionViewAutoConfigure:(ConfigurationInformation)configInfo;

@end

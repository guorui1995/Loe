//
//  GRCollectionView.m
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRCollectionView.h"

@implementation GRCollectionView
// 实现方法
- (instancetype)initWithFrame:(CGRect)frame collectionViewAutoConfigure:(ConfigurationInformation)configInfo {
    
    self.flowLayout = [[UICollectionViewFlowLayout alloc] init];
    
    //容错处理
    if (self = [super initWithFrame:frame collectionViewLayout:self.flowLayout]) {
        
        self.delegate = self;
        self.dataSource = self;
        
        // 其他单独的配置
        configInfo();
        
    }
    return self;
    
}

//返回组数
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 0;
}

//返回单元格个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 0;
}


// 创建的单元格
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    return nil;
}


@end

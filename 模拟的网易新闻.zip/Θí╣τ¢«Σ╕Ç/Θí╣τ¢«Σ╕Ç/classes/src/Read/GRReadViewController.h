//
//  GRReadViewController.h
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRReadViewController : UIViewController

@end

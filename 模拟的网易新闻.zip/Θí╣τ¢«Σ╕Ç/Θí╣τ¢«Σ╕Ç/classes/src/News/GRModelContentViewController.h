//
//  GRModelContentViewController.h
//  项目一
//
//  Created by Loe on 16/9/19.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRModelContentViewController : NSObject




// 新闻标题内容
/**标题*/
@property (nonatomic, strong) NSString * title;

/**图片*/
@property (nonatomic, strong) NSString * imgsrc;

/**跟帖数*/
@property (nonatomic, assign) NSInteger replyCount;

/**头视图*/
@property (nonatomic, strong) NSArray * ads;

/**新闻来源*/
@property (nonatomic, strong) NSString * source;


// 新闻类型  决定显示什么样式的单元格
/**是否是头标题*/
@property (nonatomic, assign) NSInteger hasHead;
/**三张图片*/
@property (nonatomic, strong) NSArray * imgextra;
/**大图*/
@property (nonatomic, assign) NSInteger imgType;



/**新闻网址*/
@property (nonatomic, strong) NSString * url;

/**照片编号*/
@property (nonatomic, strong) NSString * photosetID;

@end

//
//  GRlabCollection.h
//  项目一
//
//  Created by Loe on 16/9/8.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRCollectionView.h"

typedef void(^syncDataArr)(NSMutableArray * newSortArr, NSMutableArray * lastSortArr);

typedef void(^sceneSynchronize)(NSIndexPath* currentIndexPath) ;

@interface GRlabCollection : GRCollectionView
// 当前选中
@property (nonatomic, assign) NSInteger currentItem;


@property (nonatomic, strong) NSMutableArray * naviTopicDataArr;


@property (nonatomic, strong) NSMutableArray * lastTopicDataArr;


@property (nonatomic, copy) syncDataArr sortBlock;

@property (nonatomic, copy) sceneSynchronize sceneSynchronizeBlock;

@property(nonatomic,assign)BOOL  isHidden;
@end

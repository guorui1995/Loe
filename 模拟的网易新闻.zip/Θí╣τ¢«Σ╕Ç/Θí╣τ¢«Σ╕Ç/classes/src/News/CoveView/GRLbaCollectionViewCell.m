//
//  GRLbaCollectionViewCell.m
//  项目一
//
//  Created by Loe on 16/9/8.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRLbaCollectionViewCell.h"

@implementation GRLbaCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        self.label = [[UILabel alloc] initWithFrame:self.bounds];
        // 子类控件不要直接放到cell上，而是cell.contentView
        self.label.adjustsFontSizeToFitWidth = YES ;
        
        self.label.textAlignment = NSTextAlignmentCenter;
        _imge = [[UIImageView alloc]initWithFrame:self.bounds];
        
        
        
        self.deleteBtn = [[UIButton alloc ]initWithFrame:CGRectMake(-5, -5, 20, 20)];
        self.deleteBtn.alpha = 0.5;
        [self.deleteBtn setBackgroundImage:[UIImage imageNamed:@"channel_edit_delete@2x"] forState:UIControlStateNormal];
        self.deleteBtn.hidden = YES ;
        
        [self.contentView addSubview:_imge];
        [self.contentView addSubview:self.label];
        [self.contentView addSubview:self.deleteBtn];
    }
    return self;
}

// get方法的实现
- (void)setName:(NSString *)name {
    if (name != _name) {
        _name = name;
        
        self.label.text = name;
        self.label.frame = self.bounds;
    }
    
}
@end

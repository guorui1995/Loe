//
//  GRlabCollection.m
//  项目一
//
//  Created by Loe on 16/9/8.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRlabCollection.h"
#import "GRLbaCollectionViewCell.h"
#import "GRNewTopicNaviCollectionView.h"
#define cellID @"ZANewTopicNaviCellIdentifier"
#define topicMangerHeaderID @"GRTopicID"

#define  kScreenWidth  [UIScreen mainScreen].bounds.size.width
#define  kScreenheight  [UIScreen mainScreen].bounds.size.height
@implementation GRlabCollection

- (instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout {
    
    self = [super initWithFrame:frame collectionViewAutoConfigure:^{
        
        self.flowLayout.scrollDirection =  UICollectionViewScrollDirectionVertical;
        
        self.flowLayout.minimumLineSpacing = 10;
        self.flowLayout.minimumInteritemSpacing = 0;
        
        self.flowLayout.sectionInset = UIEdgeInsetsMake(15.f, 10.f, 15.f, 10.f);
        self. flowLayout.itemSize = CGSizeMake(kScreenWidth/5, 30);
        [self registerClass:[GRLbaCollectionViewCell class] forCellWithReuseIdentifier:cellID];
        [self registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:topicMangerHeaderID];
    }];

    return self;
}


- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    if (_isHidden == YES) {
        return 1 ;
    }
    
    return 2;
    
    
    
}



- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (section == 0) {
        return self.naviTopicDataArr.count;
    }else {
        return self.lastTopicDataArr.count;
    }
    
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    // 使用复用返回单元格,一定要进行注册
    GRLbaCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    
    cell.deleteBtn.hidden = YES ;
    cell.label.textColor = [UIColor blackColor];
    cell. imge.image = [UIImage imageNamed:@"channel_grid_circle@2x"];
    if (indexPath.section == 0) {
        
        if (indexPath.item ==0) {
            cell.imge.image = nil ;
            
            
            
        }
        
        if (_isHidden  == YES) {
            if (indexPath.item != 0) {
                cell.deleteBtn.hidden = NO ;
                
            }
            
        }
        
        if (indexPath.item == self.currentItem) {
            cell.label.textColor = [UIColor redColor];
            
  
        }
        
        cell.name = self.naviTopicDataArr[indexPath.item];
    }else{
        cell.name = self.lastTopicDataArr[indexPath.item];
    }
    
    
    self.userInteractionEnabled = YES;

        [cell.deleteBtn addTarget:self action:@selector(deleteBtnAction:) forControlEvents:UIControlEventTouchUpInside];

    


    
    
    
    
    return cell;
}



- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    //    GRNewTopicNaviCollectionView * vc = [[GRNewTopicNaviCollectionView alloc]init];
    if (indexPath.section == 0) {
        self.currentItem = indexPath.item;
        
        [self reloadData];
        
        self.sceneSynchronizeBlock(indexPath);
        
    }else if (indexPath.section == 1){
        
        [self.naviTopicDataArr addObject:self.lastTopicDataArr[indexPath.item]];
        
        [self.lastTopicDataArr removeObjectAtIndex:indexPath.item];
        
        self.sortBlock(self.naviTopicDataArr, self.lastTopicDataArr);
        
        [self performBatchUpdates:^{
            
            // NSIndexPath，表示之后item的位置
            NSIndexPath * moveIndexPath = [NSIndexPath indexPathForItem:self.naviTopicDataArr.count - 1 inSection:0];
            
            // 移动单元格
            [collectionView moveItemAtIndexPath:indexPath toIndexPath:moveIndexPath];
            
        } completion:^(BOOL finished) {
            
            
        }];
        
    }
    
    
    
    
    
    
}

-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    UICollectionReusableView * headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:topicMangerHeaderID forIndexPath:indexPath];
    
    UILabel * headerLab = [[UILabel alloc]initWithFrame:headerView.bounds];
    
    headerLab.text = @"  点击添加更多栏目";
    headerLab.font = [UIFont systemFontOfSize:14.f];
    
    headerLab.backgroundColor = [UIColor groupTableViewBackgroundColor];
    
    [headerView addSubview:headerLab];
    return headerView;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return CGSizeZero;
    }
    
    return CGSizeMake(0, 25.f);
}


-(void)deleteBtnAction:(UIButton *)sender{
   
    
    
    NSString * str = _naviTopicDataArr[self.currentItem];
    
    
    [_naviTopicDataArr removeObjectAtIndex:self.currentItem];
    
    [_lastTopicDataArr addObject:  str];
    
    [self reloadData];
    
    
}







@end

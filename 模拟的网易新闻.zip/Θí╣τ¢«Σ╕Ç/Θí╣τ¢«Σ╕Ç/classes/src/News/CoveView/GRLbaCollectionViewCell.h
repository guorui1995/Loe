//
//  GRLbaCollectionViewCell.h
//  项目一
//
//  Created by Loe on 16/9/8.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRLbaCollectionViewCell : UICollectionViewCell
// 话题名称
@property (nonatomic, strong) NSString * name;
// 显示话题所用的Label
@property (nonatomic, strong) UILabel * label;

@property(nonatomic,strong)UIButton * deleteBtn;

@property(nonatomic,strong)UIImageView *imge;
@end

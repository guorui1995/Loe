//
//  GRlabCollection.h
//  项目一
//
//  Created by Loe on 16/9/8.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRCollectionView.h"
//创建一个无返回值 有2个可变数组参数的block  用来传递数据
typedef void(^syncDataArr)(NSMutableArray * newSortArr, NSMutableArray * lastSortArr);
// 创建一个无返回值 有一个参数的block 用来传递当前选中单元格
typedef void(^sceneSynchronize)(NSIndexPath* currentIndexPath) ;

@interface GRlabCollection : GRCollectionView
// 当前选中
@property (nonatomic, assign) NSInteger currentItem;

//显示在话题导航栏上的数据
@property (nonatomic, strong) NSMutableArray * naviTopicDataArr;

//未显示在话题导航栏上的数据
@property (nonatomic, strong) NSMutableArray * lastTopicDataArr;

// 创建block
@property (nonatomic, copy) syncDataArr sortBlock;

@property (nonatomic, copy) sceneSynchronize sceneSynchronizeBlock;

// 是否允许删除
@property (nonatomic, assign) BOOL isAllowDelete;
@end

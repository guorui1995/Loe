//
//  GRlabCollection.m
//  项目一
//
//  Created by Loe on 16/9/8.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRlabCollection.h"
#import "GRLbaCollectionViewCell.h"
#import "GRNewTopicNaviCollectionView.h"
#import "GRModelViewController.h"
#define cellID @"ZANewTopicNaviCellIdentifier"
#define topicManagerHeaderID @"ZATopicManagerHeaderIdentifier"


@interface GRlabCollection ()
//创建一拖动手势
@property (nonatomic, strong) UIPanGestureRecognizer * panGesture;
// 创建一个长按手势
@property (nonatomic, strong)  UILongPressGestureRecognizer * longPressGesture;
@end
@implementation GRlabCollection
//覆写方法
- (instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout {
    
    self = [super initWithFrame:frame collectionViewAutoConfigure:^{
        // 布局方向是垂直
        self.flowLayout.scrollDirection =  UICollectionViewScrollDirectionVertical;
        
        self.flowLayout.minimumLineSpacing = 10;
        self.flowLayout.minimumInteritemSpacing = 0;
        
        self.flowLayout.sectionInset = UIEdgeInsetsMake(15.f, 10.f, 15.f, 10.f);
        self. flowLayout.itemSize = CGSizeMake(kScreenWidth/5, 30);
        [self registerClass:[GRLbaCollectionViewCell class] forCellWithReuseIdentifier:cellID];
        [self registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:topicManagerHeaderID];
        
        self.panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(cellPanGestureAction:)];
    }];
    
    return self;
}


#pragma mark - Collection View Data Source
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    if (_isAllowDelete) {
        return 1;
    }
    return 2;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (section == 0) {
        
        return self.naviTopicDataArr.count;
    } else {
        return self.lastTopicDataArr.count;
    }
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    GRLbaCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    
    // 移除单元格上的所有手势，保证点击第1组不会有长按手势
    [cell removeGestureRecognizer:[[cell gestureRecognizers] firstObject]];
    
    // cell上删除按钮的block回调
    cell.deleteChannelBlock = ^{
        // 1.改变数组中的数据
        [self.lastTopicDataArr addObject:self.naviTopicDataArr[indexPath.item]];
        [self.naviTopicDataArr removeObjectAtIndex:indexPath.item];
        
        // 2.同步数据
        self.sortBlock(self.naviTopicDataArr, self.lastTopicDataArr);
        
        // 3.删除当前单元格
        [collectionView performBatchUpdates:^{
            [collectionView deleteItemsAtIndexPaths:@[indexPath]];
        } completion:^(BOOL finished) {
            [collectionView reloadData];
        }];
        
        // 移除底层的虚线框
        [[collectionView viewWithTag:self.naviTopicDataArr.count + 100] removeFromSuperview];
        
    };
    
    // 隐藏删除按钮，不能写在判断组内部，会导致第一组出现单元格复用
    // 长按手势
    _longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(cellLongPressGetureAction:)];
    
    cell.deleteBtn.hidden = YES;
    cell.label.textColor = [UIColor blackColor];
    cell.imge.image = [UIImage imageNamed:@"channel_grid_circle@2x"];
    
    if (indexPath.section == 0) {
        [cell addGestureRecognizer:_longPressGesture];
        GRModelViewController * model = self.naviTopicDataArr[indexPath.item];
        cell.label.text = model.tname;
        
        // 当前选中的字体是红色
        if (indexPath.item == self.currentItem) {
            cell.label.textColor = [UIColor redColor];
        }
        
        
        if (indexPath.item == 0) {
            cell.imge.image = nil;
        }
        
        
        if (_isAllowDelete) {
            
            if (indexPath.item != 0) {
                // 显示删除按钮
                cell.deleteBtn.hidden = NO;
            }
            if (indexPath.item == 0) {
                cell.label.textColor = [UIColor grayColor];
                
            }else{
                cell.label.textColor = [UIColor blackColor];
                
            }
        } else {
            
            // 添加手势
            
        }
    } else {
        GRModelViewController * model = self.lastTopicDataArr[indexPath.item];
        cell.label.text = model.tname;
        
        
    }
    return cell;
}



// 返回组头/组尾视图,一定要规定组头/组尾的高度
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    
    UICollectionReusableView * headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:topicManagerHeaderID forIndexPath:indexPath];
    
    // 使Label不会重复创建
    static UILabel * tipsLabel;
    if (!tipsLabel) {
        tipsLabel = [[UILabel alloc] initWithFrame:headerView.bounds];
        tipsLabel.text = @"    点击添加更多栏目";
        tipsLabel.font = [UIFont systemFontOfSize:14.f];
        tipsLabel.backgroundColor = [UIColor groupTableViewBackgroundColor];
    }
    [headerView addSubview:tipsLabel];
    
    return headerView;
    
}



#pragma mark - Collection View Delegate
// 点击单元格会产生的效果
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
        if (!self.isAllowDelete) {
            // 界面同步block，将当前点击的indexPath属性进行传递
            self.sceneSynchronizeBlock(indexPath);
        }
        
    } else if (indexPath.section == 1) {
        // 点击第一组单元格，那么点击的单元格，移动到第零组
        [self.naviTopicDataArr addObject:self.lastTopicDataArr[indexPath.item]];
        [self.lastTopicDataArr removeObjectAtIndex:indexPath.item];
        // 在这里将数据传递回Controller对象
        self.sortBlock(self.naviTopicDataArr, self.lastTopicDataArr);
        
        // 更新CollectionView中的单元格UI
        [self performBatchUpdates:^{
            
            // NSIndexPath，表示之后item的位置
            NSIndexPath * moveIndexPath = [NSIndexPath indexPathForItem:self.naviTopicDataArr.count - 1 inSection:0];
            
            // 移动单元格
            [collectionView moveItemAtIndexPath:indexPath toIndexPath:moveIndexPath];
            
        } completion:^(BOOL finished) {
            
            // 刷新数据
            [collectionView reloadData];
        }];
        
        
    }
    
}

#pragma mark - Collection Layout Delegate
//返回组头的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return CGSizeZero;
    }
    
    return CGSizeMake(0, 25.f);
}



#pragma mark - Private Method
- (void)cellLongPressGetureAction:(UILongPressGestureRecognizer *)gesture {
    
    if (!self.isAllowDelete) {
        
        self.isAllowDelete = YES;
        
        // 改变导航栏上的按钮，变为“完成”
        // 通过响应者链，拿到视图控制器
        UIResponder * responder = self;
        while (responder) {
            // 判断当前响应者是否是一个视图控制器
            if ([responder isKindOfClass:[UIViewController class]]) {
                // 获取视图控制器上的按钮
                UIViewController * vc = (UIViewController *)responder;
                UIButton *btn = [vc.view viewWithTag:10013];
                btn.selected = YES;
                // 如果获取跳出while循环
                //				return;
            }
            // 如果不是我要的视图控制器，那么继续遍历下一个响应者
            responder = responder.nextResponder;
            
        }
    }
    [self reloadData];
}


- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    
    if (_isAllowDelete && indexPath.section == 0) {
        if (indexPath.item == 0) {
            return;
        }
        
        if ([collectionView viewWithTag:(indexPath.item+100)]) {
            return;
        }
        
        UIImageView * imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"channel_compact_placeholder_inactive@2x"]];
        
        imageView.tag = indexPath.item + 100 ;
        imageView.bounds = CGRectMake(0, 0, 69, 29);
        imageView.center = cell.center;
        
        
        [self insertSubview:imageView belowSubview:[[collectionView subviews] firstObject ]];
        
        
    } else{
        [[collectionView viewWithTag:indexPath.item+100] removeFromSuperview];
        
    }
    
    
    
}

-(void)cellPanGestureAction:(UIPanGestureRecognizer *)panGesture{
    
    // 获取手势状态
    UIGestureRecognizerState panState = panGesture.state;
    
    // 获取手指触碰的位置
    CGPoint location = [panGesture locationInView:self];
    
    // 拿到手指触碰的单元格IndexPath信息
    NSIndexPath * indexPath = [self indexPathForItemAtPoint:location];
    
    // 定义一个将要移动位置的Cell位置信息
    static NSIndexPath * lastIndexPath = nil;
    
    // 创建弹出视图
    static UIView * popView = nil;
    
    switch (panState) {
        case UIGestureRecognizerStateBegan:
            // 是否存在单元格，并且选中位置存在,并且选中的不是头条
            
            if (indexPath && indexPath.item > 0) {
                
                lastIndexPath = indexPath;
                
                
                // 获取到当前的cell(真实存在)
                GRLbaCollectionViewCell * cell = (GRLbaCollectionViewCell *)[self cellForItemAtIndexPath:indexPath];
                
                // 创建一个弹出视图（alloc新创建的）
                GRLbaCollectionViewCell * pickCell = [[GRLbaCollectionViewCell alloc] initWithFrame:cell.bounds];
                pickCell.imge.image = [UIImage imageNamed:@"channel_grid_circle@2x"];
                GRModelViewController * model = self.naviTopicDataArr[indexPath.item];
                pickCell.label.text = model.tname;
                
                
                
                // 创建一个弹出视图（UIView），将popView的位置设置的cell位置一致
                popView = pickCell;
                popView.center = cell.center;
                [self addSubview:popView];
                
                
                [UIView animateWithDuration:0.2 animations:^{
                    // 将popView缩放
                    popView.transform = CGAffineTransformMakeScale(1.2, 1.2);
                    popView.alpha = 0.98;
                    cell.alpha = 0;
                } completion:^(BOOL finished) {
                    // 隐藏cell，为了显示后面的虚线框
                    // 隐藏会导致出现空的虚线框
                    //					cell.hidden = YES;
                }];
            }
            break;
        case UIGestureRecognizerStateChanged:
        {
            // 弹起假的视图，移动位置
            CGPoint popPoint = popView.center;
            popPoint.x = location.x;
            popPoint.y = location.y;
            popView.center = popPoint;
            
            
            if (lastIndexPath.item > 0 && indexPath.item > 0) {
                // 获取到当前的cell(真实存在)
                GRLbaCollectionViewCell * cell = (GRLbaCollectionViewCell *)[self cellForItemAtIndexPath:indexPath];
                cell.alpha = 0;
                
                
                // 判断触碰点是否在单元格上
                if (![indexPath isEqual:lastIndexPath]) {
                    
                    // 移动动画
                    [self moveItemAtIndexPath:lastIndexPath toIndexPath:indexPath];
                    
                    if (lastIndexPath.item < indexPath.item) {
                        
                        // 补位的计算
                        [self.naviTopicDataArr insertObject:self.naviTopicDataArr[lastIndexPath.item] atIndex:indexPath.item + 1];
                        
                        [self.naviTopicDataArr removeObjectAtIndex:lastIndexPath.item];
                    } else {
                        
                        // 补位的计算
                        [self.naviTopicDataArr insertObject:self.naviTopicDataArr[lastIndexPath.item] atIndex:indexPath.item];
                        
                        [self.naviTopicDataArr removeObjectAtIndex:lastIndexPath.item + 1];
                        
                    }
                    
                    // 重新设计了路径
                    lastIndexPath = indexPath;
                }
            }
        }
            break;
        case UIGestureRecognizerStateEnded:
            //		case UIGestureRecognizerStateFailed:
        {
            // 1.显示Cell
            GRLbaCollectionViewCell * cell = (GRLbaCollectionViewCell *)[self cellForItemAtIndexPath:lastIndexPath];
            //			cell.hidden = NO;
            
            [UIView animateWithDuration:0.2 animations:^{
                cell.alpha = 1;
                popView.center = cell.center;
                popView.transform = CGAffineTransformIdentity;
                popView.alpha = 0;
                
            } completion:^(BOOL finished) {
                [popView removeFromSuperview];
                popView = nil;
                lastIndexPath = nil;
                
                
                [self reloadData];
                
                
                // 同步改变首页内容
                self.sortBlock(self.naviTopicDataArr, self.lastTopicDataArr);
            }];
        }
            break;
    }
}




#pragma mark - OverrideMethod
- (void)setIsAllowDelete:(BOOL)isAllowDelete {
    if (_isAllowDelete != isAllowDelete) {
        _isAllowDelete = isAllowDelete;
        
        // 判断是否需要添加移动手势
        if (_isAllowDelete) {
            [self addGestureRecognizer:self.panGesture];
        } else if (!isAllowDelete) {
            [self removeGestureRecognizer:self.panGesture];
        }
        
        // 如果数据不同就刷新单元格
        [self reloadData];
    }
}







@end

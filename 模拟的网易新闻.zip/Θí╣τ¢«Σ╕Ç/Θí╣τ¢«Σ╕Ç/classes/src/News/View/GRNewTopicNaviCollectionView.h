//
//  GRNewTopicNaviCollectionView.h
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRCollectionView.h"

@interface GRNewTopicNaviCollectionView : GRCollectionView
@property (nonatomic, strong) NSArray * dataArr;

// 当前选中的Item
@property (nonatomic, assign) NSInteger currentItem;
@end

//
//  GRMCollectionViewCell.m
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRMCollectionViewCell.h"

@implementation GRMCollectionViewCell


//自定义初始化
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        
        
        self.vc = [[GRContentCollection alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-64-40-49)];
        
        self.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:self.vc];
        
        
        
    }
    
    return self;
}
- (void)setTopicModel:(GRModelViewController *)topicModel {
    if (_topicModel != topicModel) {
        _topicModel = topicModel;
    }
    
    // 页面tid传递
    
    
    self.vc.tid = topicModel.tid;
    
    if ([topicModel.tname isEqualToString:@"头条"]) {
        self.vc.newsType = @"headline";
    } else {
        self.vc.newsType = @"list";
    }
    
    [self.vc setValue:nil forKey:@"dataArr"];
    [self.vc setValue:@0 forKey:@"contentNum"];
    [self.vc reloadData];
    
    [self.vc.mj_header beginRefreshing];
}
@end

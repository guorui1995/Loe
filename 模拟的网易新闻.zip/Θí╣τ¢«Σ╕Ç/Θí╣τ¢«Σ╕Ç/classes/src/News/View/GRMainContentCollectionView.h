//
//  GRMainContentCollectionView.h
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRCollectionView.h"
#import "GRCollectionViewCell.h"
#import "GRNewTopicNaviCollectionView.h"
@interface GRMainContentCollectionView : GRCollectionView<UIScrollViewDelegate>
// 声明一个接受数据的数组
@property (nonatomic, strong) NSArray * topicDataArray;
// 计数当前单元格属性
@property (nonatomic, assign) NSInteger currentItem;

// 声明一个类对象
@property (nonatomic, strong) GRNewTopicNaviCollectionView * topicNavi;

@property (nonatomic, strong) NSArray * contentDataArray;
@end

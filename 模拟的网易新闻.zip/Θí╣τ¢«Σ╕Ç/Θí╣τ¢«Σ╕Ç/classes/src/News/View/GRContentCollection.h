//
//  GRContentCollection.h
//  项目一
//
//  Created by Loe on 16/9/16.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRCollectionView.h"

@interface GRContentCollection : GRCollectionView
@property (nonatomic, strong) NSMutableArray * dataArr;
@property (nonatomic, strong) NSString * tid;

@property (nonatomic, strong) NSString * newsType;


@end

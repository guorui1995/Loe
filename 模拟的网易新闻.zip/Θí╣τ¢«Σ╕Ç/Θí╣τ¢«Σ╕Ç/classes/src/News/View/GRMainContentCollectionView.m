//
//  GRMainContentCollectionView.m
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRMainContentCollectionView.h"
#import "GRMCollectionViewCell.h"
#import "GRModelViewController.h"
#import "GRContentCollection.h"

#define cellID @"ZAMainContentCellIdentifier"

@implementation GRMainContentCollectionView


//覆写方法
- (instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout{
    
    //回调
    self = [super initWithFrame:frame collectionViewAutoConfigure:^{
        // 布局
        self.flowLayout.itemSize = frame.size;
        self.flowLayout.minimumLineSpacing = 0;
        self.flowLayout.minimumInteritemSpacing = 0;
        self.flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        
        // 分页效果
        self.pagingEnabled = YES;
        [self registerClass:[GRMCollectionViewCell class] forCellWithReuseIdentifier:cellID];
        
        
    }];
    
    return self;
    
}
//返回组数
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}


//返回单元格个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return self.topicDataArray.count;
}

//创建单元格
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    GRMCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    GRModelViewController * model = self.topicDataArray[indexPath.item];
    
    cell.topicModel = model;
    cell.vc.dataArr = [self.contentDataArray mutableCopy];
    
    
    return cell;
    
}
// 结束滑动的时候
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    // 当前单元格 为滑动的长度除以屏宽
    self.currentItem = scrollView.contentOffset.x / kScreenWidth;
}




@end

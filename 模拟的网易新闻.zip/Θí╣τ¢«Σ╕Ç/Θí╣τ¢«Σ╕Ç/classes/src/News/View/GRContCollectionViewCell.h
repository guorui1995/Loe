//
//  GRContCollectionViewCell.h
//  项目一
//
//  Created by Loe on 16/9/16.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRContCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong)UIScrollView * scrollView;
@property(nonatomic,strong)UILabel * lab;
@property (nonatomic, strong) UIPageControl * pageCtrl;
@property (nonatomic, strong) NSArray * adsArr;

@property(nonatomic,strong)UIButton * btn;
@end

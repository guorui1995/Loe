//
//  GRNewsPhotoDetailViewController.m
//  项目一
//
//  Created by Loe on 16/9/27.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRNewsPhotoDetailViewController.h"
#import "GRNewsPhotoModel.h"

@interface GRNewsPhotoDetailViewController ()

@property(nonatomic,strong)UIButton *replyCountButton;
@property (strong, nonatomic) UICollectionView *collectionView;

@property (strong, nonatomic) UILabel *titleLabel;

@property (strong, nonatomic) UILabel *pagingControlLabel;

@property (strong, nonatomic)  UITextView *detailNewsLabel;

@property (nonatomic, strong) NSMutableArray * modelArr;

@end
#define cellID  @"cellID"
@implementation GRNewsPhotoDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    [self _requestData];
    [self _loadContentMainView];
}

- (void)_loadContentMainView {
    
    _replyCountButton = [[UIButton alloc]initWithFrame:CGRectMake(10, 20, 58, 44)];
    [_replyCountButton setImage:[UIImage imageNamed:@"top_navigation_back.png"] forState:UIControlStateNormal];
    [_replyCountButton addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_replyCountButton];
    
    UIButton * btn1 = [[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth-20-58-50, 20, kScreenWidth-20-58-150-20, 44)];
    [btn1 setBackgroundImage:[UIImage imageNamed:@"contentview_commentbacky@2x"] forState:UIControlStateNormal];
    [btn1 setTitle:@"233跟帖" forState:UIControlStateNormal];
    btn1.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    
    [self.view addSubview:btn1];
    
    NSString * displayString = nil;
    if (self.replyCount >= 10000) {
        displayString = [NSString stringWithFormat:@"%.1f万跟帖", self.replyCount / 10000.f];
    } else {
        displayString = [NSString stringWithFormat:@"%ld跟帖", self.replyCount];
    }
    
    [btn1 setTitle:[NSString stringWithFormat:@"%@", displayString] forState:UIControlStateNormal];
    
    
    UIView * tabBarView = [[UIView alloc]initWithFrame:CGRectMake(0, kScreenHeight-44, kScreenWidth, 44)];
    tabBarView.backgroundColor = [UIColor blackColor];
    
    [self.view addSubview:tabBarView];
    
    UITextField * textField = [[UITextField alloc]initWithFrame:CGRectMake(10, 10,180, 30)];
    
    textField.borderStyle =  UITextBorderStyleRoundedRect;
    
    textField.backgroundColor = [UIColor whiteColor];
    
    [tabBarView addSubview:textField];
    
    UIButton * pinlunBtn = [[UIButton alloc]initWithFrame:CGRectMake(200, 10, 66, 30)];
    
    [pinlunBtn setImage:[UIImage imageNamed:@"qa_comment_icon.png"] forState:UIControlStateNormal];
    [pinlunBtn setTitle:@"9999" forState:UIControlStateNormal];
    [tabBarView addSubview:pinlunBtn];
    
    UIButton * btn2 = [[UIButton alloc]initWithFrame:CGRectMake(200+66+10, 10, 25, 30)];
    [btn2 setImage:[UIImage imageNamed:@"cell_share_icon.png"] forState:UIControlStateNormal];
    [tabBarView addSubview:btn2];
    
    UIButton * btn3 = [[UIButton alloc]initWithFrame:CGRectMake(200+66+30, 10, kScreenWidth-200-66-30, 30)];
    [btn3 setImage:[UIImage imageNamed:@"top_navigation_more.png"] forState:UIControlStateNormal];
    [tabBarView addSubview:btn3];
    
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc]init];
    layout.itemSize = CGSizeMake(kScreenWidth, kScreenHeight-64-44-90);
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    layout.minimumLineSpacing = 0;
    layout.minimumInteritemSpacing = 0 ;
    _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 64, kScreenWidth, kScreenHeight-64-44-90) collectionViewLayout:layout];
    
    [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:cellID];
    
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    _collectionView.pagingEnabled = YES ;
    
    [self.view addSubview:_collectionView];
    
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, kScreenHeight-44-90, 300, 20)];
    _titleLabel.textColor = [UIColor whiteColor];
    [self.view addSubview:_titleLabel];
    
    _pagingControlLabel = [[UILabel alloc]initWithFrame:CGRectMake(300, kScreenHeight-44-90, kScreenWidth-300, 20)];
    _pagingControlLabel.textAlignment = NSTextAlignmentRight;
    _pagingControlLabel.textColor = [UIColor whiteColor];
    [self.view addSubview:_pagingControlLabel];
    
    _detailNewsLabel = [[UITextView alloc ]initWithFrame:CGRectMake(0, kScreenHeight-44-70, kScreenWidth, 70)];
    _detailNewsLabel.backgroundColor = [UIColor blackColor];
    _detailNewsLabel.textColor = [UIColor whiteColor];
    _detailNewsLabel.editable = NO;
    _detailNewsLabel.font = [UIFont boldSystemFontOfSize:15.f];
    [self.view addSubview:_detailNewsLabel];
    
}
-(void)_requestData {
    
    
    
    // 去掉前面的00AP
    NSString * newsID = [self.photosetID substringFromIndex:4];
    
    // 接口要的是|左右部分
    NSArray * components = [newsID componentsSeparatedByString:@"|"];
    
    // 拼接网址
    NSString * url = [NSString stringWithFormat:@"http://c.3g.163.com/photo/api/set/%@/%@.json", components[0], components[1]];
    
    self.modelArr = [NSMutableArray array];
    // 开启网络请求
    [[AFHTTPSessionManager manager] GET:url parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        
        NSArray * arr = responseObject[@"photos"];
        for (NSDictionary * dict in arr) {
            GRNewsPhotoModel * model = [[GRNewsPhotoModel alloc] init];
            [model yy_modelSetWithDictionary:dict];
            [self.modelArr addObject:model];
        }
        self.titleLabel.text = responseObject[@"setname"];
        
        // 数据重载
        [self.collectionView reloadData];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"%@", error);
    }];
    
    
}
#pragma mark - Collection view data source
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.modelArr.count;
}



- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    UICollectionViewCell * cell = [collectionView  dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    
    GRNewsPhotoModel * model = self.modelArr[indexPath.item];
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:cell.bounds];
    
    [imageView sd_setImageWithURL:[NSURL URLWithString:model.imgurl] placeholderImage:[UIImage imageNamed:@"cell_image_background@2x"]];
    [cell.contentView addSubview:imageView];
    
    [self setContentLabel:model indexPath:indexPath];
    
    
    
    return cell ;
}
- (void)setContentLabel:(GRNewsPhotoModel *)model indexPath:(NSIndexPath*)indexPath {
    self.detailNewsLabel.text = model.note;
    self.pagingControlLabel.text = [NSString stringWithFormat:@"%ld/%ld", indexPath.item + 1, self.modelArr.count];
}

-(void)btnAction:(UIButton *)sender{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

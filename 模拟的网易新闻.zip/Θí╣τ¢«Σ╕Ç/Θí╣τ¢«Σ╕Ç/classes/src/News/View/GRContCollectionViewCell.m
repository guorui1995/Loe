//
//  GRContCollectionViewCell.m
//  项目一
//
//  Created by Loe on 16/9/16.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRContCollectionViewCell.h"


@interface GRContCollectionViewCell () <UIScrollViewDelegate>

@end

@implementation GRContCollectionViewCell


- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        
        
        _scrollView = [[UIScrollView alloc]initWithFrame:self.bounds];
        
        _scrollView.pagingEnabled = YES ;
        
        _scrollView.delegate = self;
        [self.contentView addSubview:_scrollView];
        
        
        
        
        _btn  = [[UIButton alloc]initWithFrame:self.bounds];
        
        [self.contentView addSubview:_btn];
        
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, self.bounds.size.height-30, kScreenWidth, 30)];
        
        view.backgroundColor = [UIColor grayColor];
        view.alpha = 0.8;
        [self.contentView addSubview:view];
        
        
        _lab = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, kScreenWidth-90, 30)];
        
        
        _lab.adjustsFontSizeToFitWidth = YES ;
        
        [view addSubview:_lab];
        
        self.pageCtrl = [[UIPageControl alloc]initWithFrame:CGRectMake(kScreenWidth-70, 0, 70, 30)];
        
        
        [view addSubview: self.pageCtrl];
        
    }
    
    
    return self;
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    // 获取偏移量
    CGPoint point = scrollView.contentOffset;
    NSInteger currentNum = point.x / kScreenWidth;
    
    if (scrollView == _scrollView) {
        if (currentNum == 6) {
            [scrollView setContentOffset:CGPointMake(kScreenWidth, 0) animated:NO];
        } else if (currentNum == 0) {
            [scrollView setContentOffset:CGPointMake(kScreenWidth * 5, 0) animated:NO];
        }
        
        currentNum--;
        if (currentNum == -1) {
            currentNum = 4;
        } else if (currentNum == 5) {
            currentNum = 0;
        }
        
        _pageCtrl.currentPage = currentNum;
        
        NSDictionary * dict = self.adsArr[currentNum];
        _lab.text = dict[@"title"];
        
    }
    
    
}

@end

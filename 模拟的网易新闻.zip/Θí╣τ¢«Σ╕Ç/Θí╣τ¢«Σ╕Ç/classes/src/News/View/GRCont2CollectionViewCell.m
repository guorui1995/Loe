//
//  GRCont2CollectionViewCell.m
//  项目一
//
//  Created by Loe on 16/9/18.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRCont2CollectionViewCell.h"

@implementation GRCont2CollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        
        _lab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 20)];
        _lab.backgroundColor = [UIColor groupTableViewBackgroundColor];
        _lab.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_lab];
        
        _image = [[UIImageView alloc]initWithFrame:CGRectMake(0*(kScreenWidth/3), 20, kScreenWidth/3-20, 90)];
        
        _image1 = [[UIImageView alloc]initWithFrame:CGRectMake(1*(kScreenWidth/3)-10, 20, kScreenWidth/3-10, 90)];
        
        _image2 = [[UIImageView alloc]initWithFrame:CGRectMake(2*(kScreenWidth/3)-10, 20, kScreenWidth/3, 90)];
        _lab1 = [[UILabel alloc]initWithFrame:CGRectMake(10, self.bounds.size.height-20, 200, 20)];
        _lab2 = [[UILabel alloc]initWithFrame:CGRectMake(200, self.bounds.size.height-20, kScreenWidth-200, 20)];
        _lab2.textAlignment = NSTextAlignmentRight;
        _lab2.textColor = [UIColor grayColor];
        _lab1.textColor = [UIColor grayColor];

         [self.contentView addSubview:_lab1];
         [self.contentView addSubview:_lab2];
        [self.contentView addSubview:_image];
        [self.contentView addSubview:_image1];
        [self.contentView addSubview:_image2];
        
    }
    
    
    return self;
}

@end

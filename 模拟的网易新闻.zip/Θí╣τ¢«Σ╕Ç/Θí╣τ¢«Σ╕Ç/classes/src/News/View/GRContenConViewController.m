//
//  GRContenConViewController.m
//  项目一
//
//  Created by Loe on 16/9/23.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRContenConViewController.h"

@interface GRContenConViewController ()

@end

@implementation GRContenConViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    [self _requestData];
    
    
}


-(void) _requestData{
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(10, 20, 58, 44)];
    [btn setImage:[UIImage imageNamed:@"top_navigation_back.png"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:btn];
    
    UIButton * btn1 = [[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth-20-58-50, 20, kScreenWidth-20-58-150-20, 44)];
    [btn1 setBackgroundImage:[UIImage imageNamed:@"contentview_commentbacky@2x"] forState:UIControlStateNormal];
    [btn1 setTitle:@"233跟帖" forState:UIControlStateNormal];
    btn1.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIWebView * webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 20+44, kScreenWidth, kScreenHeight-20-49)];
    
    webView.backgroundColor = [UIColor redColor];
    [self.view addSubview:webView];
    [self.view addSubview:btn1];
    
    NSString * displayString = nil;
    if (self.replyCount >= 10000) {
        displayString = [NSString stringWithFormat:@"%.1f万跟帖", self.replyCount / 10000.f];
    } else {
        displayString = [NSString stringWithFormat:@"%ld跟帖", self.replyCount];
    }
    
    [btn1 setTitle:[NSString stringWithFormat:@"%@", displayString] forState:UIControlStateNormal];
    
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.urlString]]];
    
    
    
}
-(void)btnAction:(UIButton *)sender{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

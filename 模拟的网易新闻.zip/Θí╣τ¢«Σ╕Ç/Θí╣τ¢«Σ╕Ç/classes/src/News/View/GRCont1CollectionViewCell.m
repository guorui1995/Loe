//
//  GRCont1CollectionViewCell.m
//  项目一
//
//  Created by Loe on 16/9/18.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRCont1CollectionViewCell.h"

@implementation GRCont1CollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        _imge = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 90, 90)];
        
        
        _lab = [[UILabel alloc]initWithFrame:CGRectMake(110,0, kScreenWidth-110        , 90)];
        _lab.numberOfLines = 0 ;
        _lab.font = [UIFont systemFontOfSize:18.f];
        
        
        
        _lab1 = [[UILabel alloc]initWithFrame:CGRectMake(110, 80, kScreenWidth-110-100, 20)];
        
        
        _lab1.textColor = [UIColor grayColor];
        
        _lab2 = [[UILabel alloc]initWithFrame:CGRectMake(kScreenWidth-100 -100, 80, 200, 20)];
        _lab2.textAlignment = NSTextAlignmentRight;
        _lab2.textColor = [UIColor grayColor];
        [self.contentView addSubview:_lab];
        [self.contentView addSubview:_imge];
        [self.contentView addSubview:_lab1];
        [self.contentView addSubview:_lab2];
        
        
    }
    
    
    return self;
}

@end

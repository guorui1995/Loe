//
//  GRNewTopicNaviCollectionView.m
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRNewTopicNaviCollectionView.h"
#import "GRCollectionViewCell.h"
#import "GRModelViewController.h"

#define cellID @"ZANewTopicNaviCellIdentifier"
@implementation GRNewTopicNaviCollectionView
//覆写方法
- (instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout {
    //回调布局
    self = [super initWithFrame:frame collectionViewAutoConfigure:^{
        self.backgroundColor = [UIColor whiteColor];
        
        // 设置滑动方向
        self.flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        
        // 隐藏滑动条
        self.showsVerticalScrollIndicator = NO;
        self.showsHorizontalScrollIndicator = NO;
        
        // 因为对不同的单元格需要不同的大小
        //		// 设置单元格大小
        //		flowLayout.itemSize
        self.flowLayout.minimumLineSpacing = 10;
        self.flowLayout.minimumInteritemSpacing = 0;
        
        //        self.flowLayout.sectionInset = UIEdgeInsetsMake(0, 15.f, 0, 15.f);
        
        [self registerClass:[GRCollectionViewCell class] forCellWithReuseIdentifier:cellID];
    }];
    
    
    return self;
}





#pragma mark - Collection data source



- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}



- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataArr.count;
}



- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    // 使用复用返回单元格,一定要进行注册
    GRCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    if (indexPath.item == self.currentItem) {
        [UIView animateWithDuration:0.5 animations:^{
            cell.label.textColor = [UIColor redColor];
            cell.label.transform = CGAffineTransformMakeScale(1.15,1.3);
        }];
        
    }else{
        
        cell.label.textColor = [UIColor blackColor];
        cell.label.transform = CGAffineTransformIdentity;
        
    }
    GRModelViewController * model = self.dataArr[indexPath.item];
    
    // 将cell内的字符串赋值
    cell.name = model.tname;
    
    
    
    return cell;
}




#pragma mark - Collection Delegate
//选中状态的单元格
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    // 保留选中单元格位置
    self.currentItem = indexPath.item;
    
    // 让单元格滑到居中显示
    [collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
}




#pragma mark - Collection delegate layout
// 返回单元格大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    GRModelViewController * model = self.dataArr [indexPath.item];
    CGRect rect = [model.tname boundingRectWithSize:CGSizeMake(999, 30.f) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:20]} context:nil];
    
    
    
    return CGSizeMake ( rect.size.width + 20.f , self.frame.size.height);
}

//- (void)setdataArr:(NSArray *)dataArr {
//    if (_dataArr != dataArr) {
//        _dataArr = dataArr;
//
//        [self reloadData];
//    }
//}

@end

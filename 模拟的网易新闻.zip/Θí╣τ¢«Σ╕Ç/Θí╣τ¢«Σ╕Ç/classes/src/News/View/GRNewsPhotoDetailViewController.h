//
//  GRNewsPhotoDetailViewController.h
//  项目一
//
//  Created by Loe on 16/9/27.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRNewsPhotoDetailViewController : UIViewController<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UICollectionViewDelegate>


/**跟帖数*/
@property (nonatomic, assign) NSInteger replyCount;


/**照片编号*/
@property (nonatomic, strong) NSString * photosetID;

-(void)_requestData;
@end

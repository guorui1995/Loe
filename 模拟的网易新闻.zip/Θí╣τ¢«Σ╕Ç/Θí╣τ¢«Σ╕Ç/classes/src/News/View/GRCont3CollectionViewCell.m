//
//  GRCont3CollectionViewCell.m
//  项目一
//
//  Created by Loe on 16/9/18.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRCont3CollectionViewCell.h"

@implementation GRCont3CollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        _lab = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, kScreenWidth-20, 20)];
        _lab1 = [[UILabel alloc]initWithFrame:CGRectMake(10, self.bounds.size.height-20, 200, 20)];
        _lab2 = [[UILabel alloc]initWithFrame:CGRectMake(200, self.bounds.size.height-20, kScreenWidth-200, 20)];
        _image1 = [[UIImageView alloc]initWithFrame:CGRectMake(10, 20, kScreenWidth-20, self.bounds.size.height-20-20)];
        _lab2.textAlignment = NSTextAlignmentRight;
        _lab2.textColor = [UIColor grayColor];
        _lab1.textColor = [UIColor grayColor];
        
        [self.contentView addSubview:_image1];
        [self.contentView addSubview:_lab];
          [self.contentView addSubview:_lab1];
          [self.contentView addSubview:_lab2];
    }
    
    
    return self;
}

@end

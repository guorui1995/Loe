//
//  GRCont1CollectionViewCell.h
//  项目一
//
//  Created by Loe on 16/9/18.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRCont1CollectionViewCell : UICollectionViewCell
@property(nonatomic,strong) UIImageView * imge;
@property(nonatomic,strong) UILabel * lab;
@property(nonatomic,strong) UILabel * lab1;
@property(nonatomic,strong) UILabel * lab2;

@end

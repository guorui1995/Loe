//
//  GRContentCollection.m
//  项目一
//
//  Created by Loe on 16/9/16.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRContentCollection.h"
#import "GRContCollectionViewCell.h"
#import "GRCont1CollectionViewCell.h"
#import "GRCont2CollectionViewCell.h"
#import "GRCont3CollectionViewCell.h"
#import "GRModelContentViewController.h"
#import "GRContenConViewController.h"
#import "GRNewsPhotoDetailViewController.h"

#define cellID1 @"ZAMainContentCellIdentifier"
#define cellID2 @"ZAMainContentCellIdentifier2"
#define cellID3 @"ZAMainContentCellIdentifier3"
#define cellID4 @"ZAMainContentCellIdentifier4"

#define kNewsBaseURL @"http://c.m.163.com/nc/article"
@interface GRContentCollection()
@property(nonatomic,strong)GRModelContentViewController * model;
@property(nonatomic,strong)GRContCollectionViewCell * cell;

// 请求网络地址
@property (nonatomic, strong) NSString * requestURLString;

@property (nonatomic, assign) NSInteger contentNum;

@property (nonatomic, strong) NSArray * adsArr;

@end

@implementation GRContentCollection

//覆写方法
- (instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout{
    
    //回调
    self = [super initWithFrame:frame collectionViewAutoConfigure:^{
        // 布局
        
        
        self.flowLayout.minimumLineSpacing = 5;
        self.flowLayout.minimumInteritemSpacing = 5;
        self.flowLayout.scrollDirection =  UICollectionViewScrollDirectionVertical;
        
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        self.backgroundColor = [UIColor whiteColor];
        
        
        [self registerClass:[GRContCollectionViewCell class] forCellWithReuseIdentifier:cellID1];
        
        [self registerClass:[GRCont1CollectionViewCell class] forCellWithReuseIdentifier:cellID2];
        
        [self registerClass:[GRCont2CollectionViewCell class] forCellWithReuseIdentifier:cellID3];
        [self registerClass:[GRCont3CollectionViewCell class] forCellWithReuseIdentifier:cellID4];
        self.dataArr = [NSMutableArray array];
        
        
    }];
    MJRefreshStateHeader * headerRefresh = [MJRefreshStateHeader headerWithRefreshingBlock:^{
        NSString * preURL = [NSString stringWithFormat:@"%@/%@/%@", kNewsBaseURL, self.newsType, self.tid];
        self.requestURLString = [NSString stringWithFormat:@"%@/%d-%ld.html", preURL, 0, _contentNum + 20];
        
        [self containDataWithType:0];
    }];
    self.mj_header = headerRefresh;
    // 上拉加载
    self.mj_footer = [MJRefreshBackStateFooter footerWithRefreshingBlock:^{
        
        // 1.改变请求的新闻条数
        _contentNum += 20;
        
        // 2.改变请求数据的地址
        NSString * preURL = [NSString stringWithFormat:@"%@/%@/%@", kNewsBaseURL, self.newsType, self.tid];
        self.requestURLString = [NSString stringWithFormat:@"%@/%ld-%ld.html", preURL, _contentNum, _contentNum + 20];
        
        // 3.请求数据
        [self containDataWithType:1];
        
    }];
    
    return self;
    
}
- (void)containDataWithType:(NSInteger)type {
    
    AFHTTPSessionManager * contentManager = [AFHTTPSessionManager manager];
    
    if (type == 0) {
        
        [contentManager POST:self.requestURLString parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
            
            // 1.初始化数组
            self.dataArr = [NSMutableArray array];
            // 上拉刷新数据时，首先需要清空数组
            [self.dataArr removeAllObjects];
            
            NSArray * responseArray =  responseObject[self.tid];
            
            for (NSDictionary * dict in responseArray) {
                _model = [[GRModelContentViewController alloc] init];
                [_model yy_modelSetWithDictionary:dict];
                [self.dataArr addObject:_model];
            }
            
            [self reloadData];
            
            // 结束上拉刷新
            [self.mj_header endRefreshing];
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            // 结束上拉刷新
            [self.mj_header endRefreshing];
            
            NSLog(@"%@", error);
        }];
        
    } else if (type == 1) {
        
        [contentManager POST:self.requestURLString parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
            
            
            // 解析数据
            NSArray * responseArray = responseObject[self.tid];
            
            for (NSDictionary * dict in responseArray) {
                GRModelContentViewController * model = [[GRModelContentViewController alloc] init];
                [model yy_modelSetWithDictionary:dict];
                // 判断model是否有ads属性，如果有，直接舍弃
                if (!model.ads) {
                    [self.dataArr addObject:model];
                }
            }
            
            [self reloadData];
            
            // 结束上拉刷新
            [self.mj_footer endRefreshing];
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            // 结束上拉刷新
            [self.mj_footer endRefreshing];
            
            NSLog(@"%@", error);
        }];
        
    }
    
    
}
//返回组数
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}


//返回单元格个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataArr.count ;
    
}

//创建单元格
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {\
    
    _cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID1 forIndexPath:indexPath];
    GRCont1CollectionViewCell * cell1 = [collectionView dequeueReusableCellWithReuseIdentifier:cellID2 forIndexPath:indexPath];
    
    GRCont2CollectionViewCell * cell2 = [collectionView dequeueReusableCellWithReuseIdentifier:cellID3 forIndexPath:indexPath];
    GRCont3CollectionViewCell * cell3 = [collectionView dequeueReusableCellWithReuseIdentifier:cellID4 forIndexPath:indexPath];
    
    _model = _dataArr[indexPath.item];
    
    if (_model.hasHead) {
        
        
        
        if (_model.ads.count > 1) {
            _cell.adsArr = _model.ads;
            _adsArr = _model.ads;
            _cell.btn.hidden = YES;
            _cell.scrollView.hidden = NO;
            _cell.pageCtrl.hidden = NO;
            
            _cell. scrollView.contentSize = CGSizeMake((_model.ads.count+2) * kScreenWidth, 0);
            
            for (int i = 0; i< _model.ads.count + 2; i++) {
                UIButton * imagebtn = [[UIButton alloc]initWithFrame:CGRectMake(i*kScreenWidth, 0, kScreenWidth, 150)];
                NSDictionary * dict;
                
                if (i == 0) {
                    dict = [_model.ads lastObject];
                    imagebtn.tag = 100 + 4;
                } else if (i == _model.ads.count + 1) {
                    dict = [_model.ads firstObject];
                    imagebtn.tag = 100 + 0;
                } else {
                    dict = _model.ads[i - 1];
                    imagebtn.tag = 100 + i - 1;
                }
                
                
                
                [imagebtn sd_setImageWithURL:[NSURL URLWithString:dict[@"imgsrc"]] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"cell_image_background@2x"]];
                [imagebtn addTarget:self action:@selector( headerButtonAction: )forControlEvents:UIControlEventTouchUpInside];
                _cell.lab.text = _model.ads[0][@"title"];
                
                [_cell.scrollView addSubview:imagebtn];
            }
            
            _cell.pageCtrl.numberOfPages = _model.ads.count ;
            _cell.scrollView.contentOffset = CGPointMake(kScreenWidth, 0);
            
        }else{
            _cell.btn.hidden = NO;
            _cell.scrollView.hidden = YES ;
            _cell.pageCtrl.hidden = YES ;
            cell3. image1.image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld.jpg",indexPath.item-6]];
            _cell.btn.tag = indexPath.item+100;
            [_cell.btn sd_setBackgroundImageWithURL:[NSURL URLWithString:_model.imgsrc] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"cell_image_background@2x"]];
            _cell.lab.text = _model.title;
            [_cell.btn addTarget:self action:@selector( headerButtonAction1: )forControlEvents:UIControlEventTouchUpInside];
            
        }
        
        
        return _cell;
    }else if ( _model.imgType > 0 ){
        
        cell3.lab.text = _model.title;
        cell3. lab1.text = _model.source;
        cell3. lab2.text = [NSString stringWithFormat:@"%ld跟帖", _model.replyCount];

        
        [cell3.image1 sd_setImageWithURL:[NSURL URLWithString:_model.imgsrc] placeholderImage:[UIImage imageNamed:@"cell_image_background@2x"]];
        
        return cell3;
        
    }else if(_model.imgextra){
        
        
        cell2.lab.text = _model.title;
        
        
        [cell2.image sd_setImageWithURL:[NSURL URLWithString:_model.imgsrc] placeholderImage:[UIImage imageNamed:@"cell_image_background@2x"]];
        
        [cell2.image1 sd_setImageWithURL:[NSURL URLWithString:_model.imgextra[0][@"imgsrc"]] placeholderImage:[UIImage imageNamed:@"cell_image_background@2x"]];
        
        [cell2.image2 sd_setImageWithURL:[NSURL URLWithString:_model.imgextra[1][@"imgsrc"]] placeholderImage:[UIImage imageNamed:@"cell_image_background@2x"]];
        
        cell2. lab1.text = _model.source;
        cell2. lab2.text = [NSString stringWithFormat:@"%ld跟帖", _model.replyCount];
        return cell2;
        
    }else{
        
        cell1.backgroundColor = [UIColor groupTableViewBackgroundColor];
        
        [cell1.imge sd_setImageWithURL:[NSURL URLWithString:_model.imgsrc] placeholderImage:[UIImage imageNamed:@"cell_image_background@2x"]];
        cell1.lab.text = _model.title;
        
        
        [cell1 textInputContextIdentifier];
        cell1. lab1.text = _model.source;
        cell1. lab2.text = [NSString stringWithFormat:@"%ld跟帖", _model.replyCount];
        
        return cell1;
        
    }
    
    
}


-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    _cell =  (GRContCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    
    GRCont2CollectionViewCell * cell2 =(GRCont2CollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    
    _model = self.dataArr[indexPath.item];
    if(  [cell2.reuseIdentifier isEqualToString:@"ZAMainContentCellIdentifier3"]    ){
        GRNewsPhotoDetailViewController * photoVc = [[GRNewsPhotoDetailViewController alloc]init];
        UITabBarController * mainVC = (UITabBarController *)[UIApplication sharedApplication].keyWindow.rootViewController;
        UINavigationController * navi = mainVC.viewControllers[0];
        
        [navi pushViewController:photoVc animated:YES];
        
        photoVc.replyCount = _model.replyCount;
        photoVc.photosetID = _model.photosetID;
        
    }else {
        GRContenConViewController * vc = [[GRContenConViewController alloc]init];
        
        UITabBarController * mainVC = (UITabBarController *)[UIApplication sharedApplication].keyWindow.rootViewController;
        UINavigationController * navi = mainVC.viewControllers[0];
        
        [navi pushViewController:vc animated:YES];
        
        
        vc.replyCount = _model.replyCount;
        vc.urlString = _model.url;
        
        
    }
    
    
}


-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    _model = _dataArr[indexPath.item];
    if (_model.hasHead) {
        return CGSizeMake([UIScreen mainScreen].bounds.size.width, 150) ;
    }else if( _model.imgType){
        return CGSizeMake([UIScreen mainScreen].bounds.size.width, 120) ;
    }else if(_model.imgextra){
        return CGSizeMake([UIScreen mainScreen].bounds.size.width, 130) ;
    }else{
        
        return CGSizeMake([UIScreen mainScreen].bounds.size.width, 110) ;
    }
    
    
}
-(void)setDataArr:(NSMutableArray *)dataArr{
    if (_dataArr !=dataArr) {
        _dataArr = dataArr;
        [self reloadData];
    }
}


- (void)headerButtonAction:(UIButton *)sender {
    
    NSDictionary * dict = _adsArr[sender.tag - 100];
    
    
    if ([dict[@"tag"] isEqualToString:@"photoset"]) {
        
        
        GRNewsPhotoDetailViewController * photoVc = [[GRNewsPhotoDetailViewController alloc]init];
        // 不能直接在这里进行控件上面的赋值
        photoVc.photosetID = dict[@"url"];
        
        
        UIResponder * responder = self;
        while (responder) {
            // 拿到下一个响应者
            responder = responder.nextResponder;
            if ([responder isKindOfClass:[UIViewController class]]) {
                UIViewController * vc = (UIViewController *)responder;
                [vc.navigationController pushViewController:photoVc animated:YES];
            }
        }
        
    } else {
        
        
        GRContenConViewController * detailTextVC = [[GRContenConViewController alloc]init];
        
        
        NSString * urlString = [NSString stringWithFormat:@"http://c.3g.163.com/nc/article/%@/full.html", dict[@"url"]];
        
        detailTextVC.urlString = urlString;
        
        // 拿到当前应用程序的主window
        UITabBarController * mainVC = (UITabBarController *)[UIApplication sharedApplication].keyWindow.rootViewController;
        UINavigationController * navi = mainVC.viewControllers[0];
        
        [navi pushViewController:detailTextVC animated:YES];
        
        
    }
    
    
    
}

- (void)headerButtonAction1:(UIButton *)sender {
    _model = self.dataArr[sender.tag-100];
    
    if(_model.photosetID ){
        GRNewsPhotoDetailViewController * photoVc = [[GRNewsPhotoDetailViewController alloc]init];
        UITabBarController * mainVC = (UITabBarController *)[UIApplication sharedApplication].keyWindow.rootViewController;
        UINavigationController * navi = mainVC.viewControllers[0];
        
        [navi pushViewController:photoVc animated:YES];
        
        photoVc.replyCount = _model.replyCount;
        photoVc.photosetID = _model.photosetID;
        
    }else {
        GRContenConViewController * vc = [[GRContenConViewController alloc]init];
        
        UITabBarController * mainVC = (UITabBarController *)[UIApplication sharedApplication].keyWindow.rootViewController;
        UINavigationController * navi = mainVC.viewControllers[0];
        
        [navi pushViewController:vc animated:YES];
        
        
        vc.replyCount = _model.replyCount;
        vc.urlString = _model.url;
        
        
    }
    
}
@end

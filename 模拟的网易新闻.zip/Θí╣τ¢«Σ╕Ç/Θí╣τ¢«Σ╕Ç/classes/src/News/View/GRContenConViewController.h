//
//  GRContenConViewController.h
//  项目一
//
//  Created by Loe on 16/9/23.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRContenConViewController : UIViewController

/**跟帖数*/
@property (nonatomic, assign) NSInteger replyCount;

/**请求网址*/
@property (nonatomic, strong) NSString * urlString;
@end

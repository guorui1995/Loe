//
//  GRModelViewController.m
//  项目一
//
//  Created by Loe on 16/9/12.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRModelViewController.h"

@interface GRModelViewController ()

@end

@implementation GRModelViewController


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

//
//  GRNewsPhotoModel.h
//  项目一
//
//  Created by Loe on 16/9/27.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GRNewsPhotoModel : NSObject

/**图片地址*/
@property (nonatomic, strong) NSString * imgurl;

/**新闻内容*/
@property (nonatomic, strong) NSString * note;

@end

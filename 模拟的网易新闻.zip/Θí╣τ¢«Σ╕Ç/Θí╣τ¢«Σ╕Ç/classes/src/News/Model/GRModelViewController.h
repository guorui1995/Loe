//
//  GRModelViewController.h
//  项目一
//
//  Created by Loe on 16/9/12.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRModelViewController : NSObject
// 话题名字
@property(nonatomic,strong)NSString * tname;


//是否是头条数据

@property(nonatomic,assign)BOOL headLine;

// subnum:超过 1000万

@property(nonatomic,strong)NSString * subnum;

@property(nonatomic,strong)NSString *tid;

// 话题所在位置

@property(nonatomic,assign)BOOL hasIcon;



@end

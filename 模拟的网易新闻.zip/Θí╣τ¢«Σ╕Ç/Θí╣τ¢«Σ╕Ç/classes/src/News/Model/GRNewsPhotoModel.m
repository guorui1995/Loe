//
//  GRNewsPhotoModel.m
//  项目一
//
//  Created by Loe on 16/9/27.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRNewsPhotoModel.h"

@implementation GRNewsPhotoModel

@end

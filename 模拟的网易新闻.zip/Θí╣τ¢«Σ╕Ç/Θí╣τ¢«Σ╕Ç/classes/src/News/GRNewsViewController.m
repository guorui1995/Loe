//
//  GRNewsViewController.m
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import "GRNewsViewController.h"

#import "GRMainContentCollectionView.h"
#import "GRNewTopicNaviCollectionView.h"
#import "GRlabCollection.h"


#import "GRModelViewController.h"
#import "GRModelContentViewController.h"
#import "GRContentCollection.h"
#import "GRMCollectionViewCell.h"
#define bgNaviHeight 40.f
@interface GRNewsViewController ()
// 导航栏数据
@property (nonatomic, strong) NSMutableArray * topNaviDataArr;
// 未添加到导航栏的话题数组
@property (nonatomic, strong) NSMutableArray * lastTopicDataArr;
// 内容视图数据

@property (nonatomic, strong) NSMutableArray * contentDataArr;
// 话题导航栏视图
@property (nonatomic, strong)GRNewTopicNaviCollectionView * topicNaviCollectionView;

// 主内容视图
@property (nonatomic, strong) GRMainContentCollectionView * contentCollectionView;

@property (nonatomic, strong) GRContentCollection * contentView;

@property(nonatomic,strong)GRlabCollection * scrollView;




@end

@implementation GRNewsViewController




- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor greenColor];
    
    //    配置导航栏内容
    [self _confignavibar];
    
    // 加载主界面数据
    
    [self _loadMainViewData1];
    
    // 加载页面的主要内容
    [self _loadContentMainView];
    
    // 加载监听
    [self _addCollectionViewObeserval];
    
}

- (void)_loadMainViewData1 {
    
    
    
    _contentView = [[GRContentCollection alloc]init];
    
    self.topNaviDataArr = [NSMutableArray array];
    self.lastTopicDataArr = [NSMutableArray arrayWithCapacity:100];
    self.contentDataArr = [NSMutableArray array];
    
    NSString * strPath = @"http://c.m.163.com/nc/topicset/ios/subscribe/manage/listspecial.html";
    
    AFHTTPSessionManager  *manager = [AFHTTPSessionManager manager];
    
    [manager GET:strPath parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary * topDic = responseObject;
        NSArray * topArr = topDic[@"tList"];
        
        for (NSDictionary *dict in topArr) {
            GRModelViewController * model = [[GRModelViewController alloc]init];
            [model yy_modelSetWithDictionary:dict];
            if (model.hasIcon) {
                if ([model.tname isEqualToString:@"头条"]) {
                    
                    [self.topNaviDataArr insertObject:model atIndex:0];
                } else {
                    [self.topNaviDataArr addObject:model];
                }
            } else {
                [self.lastTopicDataArr addObject:model];
            }
            
        }
        [self _syncViewDataArr];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"数据请求失败%@",error);
    }];
    
    
    
    
    
    
}


-(void)_confignavibar{
    //导航栏左边按钮
    UIBarButtonItem * leftItem1 = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"search_icon_highlighted@2x"] style:UIBarButtonItemStylePlain target:self action:@selector(test:)];
    leftItem1.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = leftItem1;
    
    //导航栏右边按钮
    UIBarButtonItem * righItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"top_navigation_square@2x"] style:UIBarButtonItemStylePlain target:self action:@selector(test:)];
    righItem.tintColor = [UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = righItem;
    
    //导航栏中间的视图
    UIView * view1 = [[UIView alloc]initWithFrame:CGRectMake(kScreenWidth/2-35, 0, 70, 34)];
    
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:view1.bounds];
    imageView.image= [UIImage imageNamed:@"navbar_netease@2x"];
    [self.navigationController.navigationBar addSubview:view1];
    [view1 addSubview:imageView];
    
}



- (void)_loadContentMainView {
    
    //话题单元格的高度
    
    //内容集合视图
    self.contentCollectionView = [[GRMainContentCollectionView alloc] initWithFrame:CGRectMake(0, 64 + bgNaviHeight, kScreenWidth, kScreenHeight - 64 - bgNaviHeight )];
    
    [self.view addSubview:self.contentCollectionView];
    self.automaticallyAdjustsScrollViewInsets = NO;
    //话题导航栏视图
    UIView * bgView = [[UIView alloc]initWithFrame:CGRectMake(0,64, kScreenWidth, bgNaviHeight)];
    
    bgView.backgroundColor = [UIColor whiteColor];
    bgView.tag = 10010 ;
    [self.view addSubview:bgView];
    
    
    
    //话题导航栏集合视图
    self.topicNaviCollectionView = [[GRNewTopicNaviCollectionView alloc ]initWithFrame:CGRectMake(0, 0, kScreenWidth-bgNaviHeight, bgNaviHeight)];
    
    
    
    [bgView addSubview:self.topicNaviCollectionView];
    
    // 加号按钮
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(self.topicNaviCollectionView.frame.size.width, 0, bgNaviHeight, bgNaviHeight)];
    [btn setImage:[UIImage imageNamed:@"home_header_add@2x"] forState:UIControlStateNormal];
    btn.tag = 120 ;
    [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:btn];
    
    [self _syncViewDataArr];
    
    
    
}

-(void)_loadMainView{
    self.scrollView = [[GRlabCollection alloc]initWithFrame:CGRectMake(0, - (kScreenHeight - 64 - bgNaviHeight), kScreenWidth, kScreenHeight  - 64 - bgNaviHeight)];
    
    self.scrollView.naviTopicDataArr= [self.topNaviDataArr mutableCopy] ;
    self.scrollView.lastTopicDataArr = [self.lastTopicDataArr mutableCopy];
    self.scrollView.currentItem = self.topicNaviCollectionView.currentItem;
    self.scrollView.backgroundColor = [UIColor whiteColor];
    
    [self.view insertSubview:self.scrollView belowSubview:[self.view viewWithTag:10010]];
    __weak typeof (self) weakSelf = self;
    // 数据同步block
    self.scrollView.sortBlock = ^(NSMutableArray * newSortArr, NSMutableArray * lastSortArr) {
        weakSelf.topNaviDataArr = newSortArr;
        weakSelf.lastTopicDataArr = lastSortArr;
        
        // 将其他视图中的数据进行修改
        
        [weakSelf _syncViewDataArr];
        [weakSelf.topicNaviCollectionView reloadData];
    };
    self.scrollView.sceneSynchronizeBlock = ^(NSIndexPath * currentIndexPath)
    {
        UIButton * btn = [weakSelf.view viewWithTag:120];
        [weakSelf btnAction:btn];
        
        weakSelf.contentCollectionView.currentItem = currentIndexPath.item;
        [weakSelf.contentCollectionView scrollToItemAtIndexPath:currentIndexPath atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
        
    };
    
}

- (void)_addCollectionViewObeserval {
    //监听话题导航栏单元格的属性变化
    [self.topicNaviCollectionView addObserver:self forKeyPath:@"currentItem" options:NSKeyValueObservingOptionNew context:nil];
    //监听内容单元格的属性变化
    [self.contentCollectionView addObserver:self forKeyPath:@"currentItem" options:NSKeyValueObservingOptionNew context:nil];
    
    
}
// 监听回调方法
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
    
    // 1.获取新值
    NSInteger newValue = [change[@"new"] integerValue];
    NSIndexPath * indexPath = [NSIndexPath indexPathForItem:newValue inSection:0];
    
    if (object == self.topicNaviCollectionView && self.contentCollectionView.currentItem != newValue) {
        
        // 1.修改内容视图的单元格
        self.contentCollectionView.currentItem = newValue;
        
        
        // 3.根据新值，将视图滑动到指定的位置
        [self.contentCollectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
    } else if (object == self.contentCollectionView  && self.topicNaviCollectionView.currentItem != newValue) {
        
        self.topicNaviCollectionView.currentItem = newValue;
        
        
        [self.topicNaviCollectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        
    }
    
    [self.topicNaviCollectionView reloadData];
    
}

- (void)btnAction:(UIButton *)sender {
    
    static UILabel * tipsLabel;
    static UIButton * managerButton;
    
    
    // 防止动画过程中按钮多次点击
    sender.enabled = NO;
    
    // 图标转动
    [UIView animateWithDuration:0.3 animations:^{
        sender.transform = CGAffineTransformRotate(sender.transform, M_PI_4);
    }];
    
    // 改变按钮选中状态
    sender.selected = !sender.selected;
    
    if (sender.selected == NO) {
        
        // 移除导航栏提示信息
        [tipsLabel removeFromSuperview];
        [managerButton removeFromSuperview];
        
        
        // 话题导航栏取消隐藏
        self.topicNaviCollectionView.hidden = NO;
        
        [UIView animateWithDuration:0.3 animations:^{
            self.scrollView.transform = CGAffineTransformIdentity;
            self.topicNaviCollectionView.alpha = 1;
        } completion:^(BOOL finished) {
            sender.enabled = YES;
            
            
            self.tabBarController.tabBar.hidden = NO;
            
            // 覆盖视图隐藏，移除
            self.scrollView.hidden = YES;
            [self.scrollView removeFromSuperview];
        }];
        
    } else if (sender.selected == YES) {
        
        [self  _loadMainView];
        
        [UIView animateWithDuration:0.3 animations:^{
            self.scrollView.transform = CGAffineTransformMakeTranslation(0, kScreenHeight);
            self.topicNaviCollectionView.alpha = 0;
            
            
        } completion:^(BOOL finished) {
            
            sender.enabled = YES;
            self.tabBarController.tabBar.hidden = YES;
            self.topicNaviCollectionView.hidden = YES;
            
            
            // ----------------------------
            // 创建导航栏提示信息，父视图是bgView
            UIView * bgView = [self.view viewWithTag:10010];
            
            tipsLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.f, 0.f, 80.f, bgNaviHeight)];
            tipsLabel.text = @"切换栏目";
            tipsLabel.textColor = [UIColor blackColor];
            tipsLabel.textAlignment = NSTextAlignmentCenter;
            tipsLabel.font = [UIFont systemFontOfSize:13.f];
            [bgView addSubview:tipsLabel];
            
            
            
            managerButton = [UIButton buttonWithType:UIButtonTypeCustom];
            managerButton.frame = CGRectMake(bgView.bounds.size.width - 60 - bgNaviHeight, 0.f, 60.f, bgNaviHeight);
            [managerButton setBackgroundImage:[UIImage imageNamed:@"channel_edit_button_bg@2x"] forState:UIControlStateNormal];
            [managerButton setBackgroundImage:[UIImage imageNamed:@"channel_edit_button_bg@2x"] forState:UIControlStateSelected];
            [managerButton setTitle:@"排序删除" forState:UIControlStateNormal];
            [managerButton setTitle:@"完成" forState:UIControlStateSelected];
            managerButton.tag = 10013 ;
            [managerButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            [managerButton setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
            [managerButton addTarget:self action:@selector(DeleteButton:) forControlEvents:UIControlEventTouchUpInside];
            managerButton.titleLabel.font = [UIFont systemFontOfSize:11.f];
            
            
            
            [bgView addSubview:managerButton];
            
        }];
        
    }
    
    
    
    
    
}

// 界面数据同步
-(void)_syncViewDataArr{
    self.contentCollectionView.topicDataArray = self.topNaviDataArr;
    self.topicNaviCollectionView.dataArr = self.topNaviDataArr;
    self.contentCollectionView.contentDataArray = self.contentDataArr;
    
    
    [self.topicNaviCollectionView reloadData];
    [self.contentCollectionView reloadData];
    
}

-(void)DeleteButton:(UIButton *)sender {
    sender.selected = !sender.selected;
    
    
    self.scrollView.isAllowDelete = sender.selected ;
    
    
    
    
}



-(void)test:(UIBarButtonItem *)sender{
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

//
//  GRNewsViewController.h
//  项目一
//
//  Created by Loe on 16/9/7.
//  Copyright © 2016年 loe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRNewsViewController : UIViewController
@property (nonatomic, strong) NSString * tid;

@property (nonatomic, strong) NSString * newsType;

- (void)_loadMainViewData1 ;

@end
